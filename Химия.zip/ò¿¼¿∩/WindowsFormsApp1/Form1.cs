﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

       

        private void button1_Click(object sender, EventArgs e)
        {

            int c, h, o, n, cl, br, k, a1 = 0, a2 = 0, a3 = 0, a4 = 0, a5 = 0, p;
            string s01 = "", s02 = "", s03 = "", s04 = "", s05 = "", s0 = "", s1 = "", s2 = "", q1, q2;


            c = Convert.ToInt32(textBox1.Text);
            h = Convert.ToInt32(textBox2.Text);
            o = Convert.ToInt32(textBox3.Text);
            cl =Convert.ToInt32(textBox4.Text);
            br = Convert.ToInt32(textBox5.Text);
            n = Convert.ToInt32(textBox6.Text);



            if (h == 2 * c + 2)
                if (o == 0) s2 = "ан";
                else
                    switch (o)
                    {
                        case 1:
                            {
                                //writeln(«Это может быть простой эфир, спирт или кетон.»);
                                if (checkBox1.Checked) q1 = "да"; else q1 = "Нет";
                                if (q1 == "да") s2 = "анон";
                                else
                                {
                                    if (checkBox2.Checked) q2 = "да"; else q2 = "Нет";
                                    if (q2 =="да" ) s2 ="анол";
                                    if (q2 =="нет" ) s2 ="иловый эфир";
                                }
                            }
                            break;
                        case 2:
                            s2 = "андиол"; break;
                        case 3: s2 = "антриол"; break;
                    }
            if (h == 2 * c + 1)
                if (cl == 1) { s2 ="ан"; s0 = "хлор"; }
            if (h == 2 * c + 1)
                if (br == 1) { s2 ="ан"; s0 = "бром"; }


            if (h == 2 * c)
                if (cl == 2) { s2 = "ан"; s0 = "дихлор"; }
                else if (br == 2) { s2 = "ан"; s0 = "дибром"; }
                else if (o == 1) s2 = "аналь";

                else if (o == 2) s2 = "ановая кислота";

                else
                {
                    if (checkBox1.Checked) q1 = "да"; else q1 = "Нет";
                    if (q1 == "да") s2 = "ен";
                    else { s2 = "ан"; s0 = "цикло"; }
                }

            if (h == 2 * c - 1)
                if (cl == 1)
                {
                    if (checkBox1.Checked) q1 = "да"; else q1 = "Нет";
                    q1 = Console.ReadLine();
                    if (q1 == "да") { s2 = "ен"; s0 = "хлор"; }
                    else { s2 = "ан"; s0 = "хлорцикло"; }
                    if (h == 2 * c - 1)
                        if (br == 1)
                        {
                            if (checkBox1.Checked) q1 = "да"; else q1 = "Нет";
                            if (q1 == "да") { s2 = "ен"; s0 = "бром"; }
                            else { s2 = "ан"; s0 = "бромцикло"; }
                        }
                }


            if (h == 2 * c - 2)
            {
                if (cl == 2)
                {
                    if (checkBox1.Checked) q1 = "да"; else q1 = "Нет";
                    if (q1 == "да") { s2 = "ен"; s0 = "дихлор"; }
                    else { s2 = "ан"; s0 = "дихлорцикло"; }
                }

                if (br == 2)
                {
                    if (checkBox1.Checked) q1 = "да"; else q1 = "Нет";
                    if (q1 == "да") { s2 = "ен"; s0 = "дибром"; }
                    else { s2 = "ан"; s0 = "дибромцикло"; }
                }

                if (cl == 0 && br == 0)
                {
                    if (checkBox3.Checked) q1 = "да"; else q1 = "Нет";
                    if (q1 == "да") s2 = "ин";
                    else
                    {
                        if (checkBox4.Checked) q2 = "Да"; else q2 = "нет";
                        if (q2 == "нет") s2 = "адиен";
                        else
                        {
                            s0 = "цикло"; s2 = "ен";
                        }
                    }
                }
            }

            if (h == 2 * c - 3)
                if (cl == 1) { s0 = "хлор"; s2 = "ин"; }
                else if (br == 1) { s0 = "бром"; s2 = "ин"; }
                else if (cl == 3) { s0 = "трихлорцикло"; s2 = "ан"; }
                else if (br == 3) { s0 = "трибромцикло"; s2 = "ан"; }
            if (h == 2 * c - 4)
                if (cl == 2) { s0 = "дихлор"; s2 = "ин"; }
                else if (br == 2) { s0 = "дихлор"; s2 = "ин"; }
                else if (cl == 4) { s0 = "тетрахлорцикло"; s2 = "ан"; }
                else if (br == 4) { s0 = "тетрабромцикло"; s2 = "ан"; }
            if (h == 2 * c - 5 && cl == 5) { s0 = "пентахлорцикло"; s2 = "ан"; }
            if (h == 2 * c - 5 && br == 5) { s0 = "пентабромцикло"; s2 = "ан"; }
            if (h == 2 * c - 6 && cl == 6)
            { s0 = "гексахлорцикло"; s2 = "ан"; }
            if (h == 2 * c - 6 && br == 6) { s0 = "гексабромцикло"; s2 = "ан"; }
            if (n == 1)
            {
                if (o == 0) s2 = "иламин";
                else
                    switch (o)
                    {
                        case 2: s0 = "амино"; s2 = "ановая кислота"; break;
                        case 4: s0 = "амино"; s2 = "андиовая кислота"; break;
                        case 6: s0 = "амино"; s2 = "антриовая кислота"; break;
                    }
            }

            if (n == 2)
                switch (o)
                {
                    case 2: s0 = "диамино"; s2 = "ановая кислота"; break;
                    case 4: s0 = "диамино"; s2 = "андиовая кислота"; break;
                    case 6: s0 = "диамино"; s2 = "антриовая кислота"; break;
                }

            if (n == 1)
                switch (o)
                {
                    case 2: s0 = "триамино"; s2 = "ановая кислота"; break;
                    case 4: s0 = "триамино"; ; s2 = "андиовая кислота"; break;
                    case 6: s0 = "триамино"; s2 = "антриовая кислота"; break;
                }

            if (checkBox5.Checked) q1 = "да"; else q1 = "Нет";
            if (q1 == "да")
            {
                a1 = Convert.ToInt32(textBox7.Text);
                a2 = Convert.ToInt32(textBox8.Text);
                a3 = Convert.ToInt32(textBox9.Text);
                a4 = Convert.ToInt32(textBox10.Text);
                a5 = Convert.ToInt32(textBox11.Text);

                switch (a1)
                {
                    case 1: s01 = "метил"; break;
                    case 2: s01 = "диметил"; break;
                    case 3: s01 = "триметил"; break;
                    case 4: s01 = "тетраметил"; break;
                    case 5: s01 = "пентаметил"; break;
                }


                switch (a2)
                {
                    case 1: s02 = "этил"; break;
                    case 2: s02 = "диэтил"; break;
                    case 3: s02 = "триэтил"; break;
                    case 4: s02 = "тетраэтил"; break;
                    case 5: s02 = "пентаэтил"; break;
                }


                switch (a3)
                {
                    case 1: s03 = "пропил"; break;
                    case 2: s03 = "дипропил"; break;
                    case 3: s03 = "трипропил"; break;
                    case 4: s03 = "тетрапропил"; break;
                    case 5: s03 = "пентапропил"; break;
                }

                switch (a4)
                {
                    case 1: s04 = "бутил"; break;
                    case 2: s04 = "дибутил"; break;
                    case 3: s04 = "трибутил"; break;
                    case 4: s04 = "тетрабутил"; break;
                    case 5: s04 = "пентабуТил"; break;
                }
                switch (a5)
                {
                    case 1: s05 = "пентил"; break;
                    case 2: s05 = "дипентил"; break;
                    case 3: s05 = "трипентил"; break;
                    case 4: s05 = "тетрапентил"; break;
                    case 5: s05 = "пентапентил"; break;
                }
            }

            p = h + cl + br;
            k = c - a1 - a2 * 2 - a3 * 3 - a4 * 4 - a5 * 5;
            string Otvet;

            if (p == 2 * k - 6)
            {
                if (c == 6)
                    if (h == 6)
                        if (o == 0) { Otvet = "Это вещество называется бензол"; goto lab; }
                if (h == 2 * c - 6) { Otvet = "Это вещество называется " + s01 + s02 + s03 + s04 + s05 + "бензол"; goto lab; }
                if (h == 2 * c - 7)
                {
                    if (cl == 1) { Otvet = "Это вещество называется " + s01 + s02 + s03 + s04 + s05 + "хлорбензол"; goto lab; }
                    if (br == 1) { Otvet = "Это вещество называется " + s01 + s02 + s03 + s04 + s05 + "бромбензол"; goto lab; }
                    if (n == 1)
                        if (o == 2) { Otvet = "Это вещество называется " + s01 + s02 + s03 + s04 + s05 + "нитробензол"; goto lab; }
                }

                if (c == 6)
                    if (h == 6)
                        if (o == 1) { Otvet = "Это вещество называется " + s01 + s02 + s03 + s04 + s05 + "фенол"; goto lab; }
                if (c == 6)
                    if (h == 3)
                        if (o == 1)
                            if (cl == 3) { Otvet = "Это вещество называется 2,4,6-трихлорфенол"; goto lab; }
                if (c == 6)
                    if (h == 3)
                        if (o == 1)
                            if (br == 3) { Otvet = "Это вещество называется 2,4,6-трибромфенол"; goto lab; }
                if (c == 6)
                    if (h == 3)
                        if (o == 7)
                            if (n == 3) { Otvet = "Это вещество называется 2,4,6-тринитрофенол"; goto lab; }
            }

            switch (k)
            {
                case 1: s1 = "мет"; break;
                case 2: s1 = "эт"; break;
                case 3: s1 = "проп"; break;
                case 4: s1 = "бут"; break;
                case 5: s1 = "пент"; break;
                case 6: s1 = "гекс"; break;
                case 7: s1 = "гепт"; break;
                case 8: s1 = "окт"; break;
                case 9: s1 = "нон"; break;
                case 10: s1 = "дек"; break;

            }

            Otvet = "Это вещество называется " + s01 + s02 + s03 + s04 + s05 + s0 + s1 + s2;

        lab:
            richTextBox1.Text = Otvet;
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked)
                groupBox1.Enabled = true;
            else groupBox1.Enabled = false;
        }
    }
}

