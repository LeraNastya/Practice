﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        // Переменные для отслеживания ходов и победы
        int turnCount = 0;
        bool gameOver = false;

        // Массив для хранения состояния кнопок
        string[] buttonStates = new string[9] { "0", "1", "2", "3", "4", "5", "6", "7", "8" };

        public Form1()
        {
            InitializeComponent();

            button1.Tag = buttonStates[0];
            button2.Tag = buttonStates[1];
            button3.Tag = buttonStates[2];
            button4.Tag = buttonStates[3];
            button5.Tag = buttonStates[4];
            button6.Tag = buttonStates[5];
            button7.Tag = buttonStates[6];
            button8.Tag = buttonStates[7];
            button9.Tag = buttonStates[8];
        }

        private void Button_Click(object sender, EventArgs e)
        {
            if (!gameOver) // Если игра не закончена
            {
                Button clickedButton = (Button)sender; // Получаем нажатую кнопку
                string buttonIndex = clickedButton.Tag.ToString(); // Получаем ее индекс из массива buttonStates

                if (buttonStates[int.Parse(buttonIndex)] == buttonIndex) // Если кнопка свободна
                {
                    // Меняем состояние кнопки и массива buttonStates
                    if (turnCount % 2 == 0)
                    {
                        clickedButton.BackgroundImage = Image.FromFile(System.IO.Path.Combine("Images","1.png"));
                        buttonStates[int.Parse(buttonIndex)] = "x";
                    }
                    else
                    {
                        clickedButton.BackgroundImage = Image.FromFile(System.IO.Path.Combine("Images", "2.png"));
                        buttonStates[int.Parse(buttonIndex)] = "0";
                    }

                    turnCount++;
                    if (CheckForWin())
                    {
                        gameOver = true;

                        string winner = (turnCount % 2 == 0) ? "0" : "x";
                        MessageBox.Show($"{winner} победил!");
                    }
                    else if (turnCount == 9) // Если ничья
                    {
                        gameOver = true;
                        MessageBox.Show("Ничья!");
                    }
                }
            }
        }

        private bool CheckForWin()
        {
            // Проверяем все возможные варианты победы
            return
                (buttonStates[0] == buttonStates[1] && buttonStates[1] == buttonStates[2] && buttonStates[0] != "0") ||
                (buttonStates[3] == buttonStates[4] && buttonStates[4] == buttonStates[5] && buttonStates[3] != "3") ||
                (buttonStates[6] == buttonStates[7] && buttonStates[7] == buttonStates[8] && buttonStates[6] != "6") ||

                (buttonStates[0] == buttonStates[3] && buttonStates[3] == buttonStates[6] && buttonStates[0] != "0") ||
                (buttonStates[1] == buttonStates[4] && buttonStates[4] == buttonStates[7] && buttonStates[1] != "1") ||
                (buttonStates[2] == buttonStates[5] && buttonStates[5] == buttonStates[8] && buttonStates[2] != "2") ||

                (buttonStates[0] == buttonStates[4] && buttonStates[4] == buttonStates[8] && buttonStates[0] != "0") ||
                (buttonStates[2] == buttonStates[4] && buttonStates[4] == buttonStates[6] && buttonStates[2] != "2");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            turnCount = 0;
            gameOver = false;
            for (int i = 0; i < 9; i++)
            {
                Button button = (Button)Controls.Find("button" + (i + 1), true)[0];
                button.Text = "";
                buttonStates[i] = i.ToString();
            }
            button1.Text = "";
            button2.Text = "";
            button3.Text = "";
            button4.Text = "";
            button5.Text = "";
            button6.Text = "";
            button7.Text = "";
            button8.Text = "";
            button9.Text = "";
            button1.BackgroundImage = null;
            button2.BackgroundImage = null;
            button3.BackgroundImage = null;
            button4.BackgroundImage = null;
            button5.BackgroundImage = null;
            button6.BackgroundImage = null;
            button7.BackgroundImage = null;
            button8.BackgroundImage = null;
            button9.BackgroundImage = null;
        }
    }
}
