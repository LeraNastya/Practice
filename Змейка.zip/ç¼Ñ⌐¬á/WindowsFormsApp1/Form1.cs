﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private Snake snake;
        public Form1()
        {
            InitializeComponent();

            snake = new Snake(pictureBox1, 20);
            timer1.Tick += (sender, e) => snake.Tick();

            timer1.Interval = 100;
            timer1.Start();

            pictureBox1.Focus();

            KeyPreview = true;
            KeyDown += Form1_KeyDown;
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Up:
                    snake.Directions = Snake.Direction.Up;
                    break;
                case Keys.Down:
                    snake.Directions = Snake.Direction.Down;
                    break;
                case Keys.Left:
                    snake.Directions = Snake.Direction.Left;
                    break;
                case Keys.Right:
                    snake.Directions = Snake.Direction.Right;
                    break;
            }
        }
    }
}
