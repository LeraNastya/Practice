﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public class Snake
    {
        private PictureBox pictureBox;
        private int cellSize;
        private int width;
        private int height;

        private Point[] snake;
        private Point food;
        private Direction direction;

        public int Score { get; private set; }

        public Snake(PictureBox pictureBox, int cellSize)
        {
            this.pictureBox = pictureBox;
            this.cellSize = cellSize;
            width = pictureBox.ClientSize.Width / cellSize;
            height = pictureBox.ClientSize.Height / cellSize;

            pictureBox.Paint += PictureBox_Paint;
            pictureBox.KeyDown += PictureBox_KeyDown;

            Reset();
        }

        public void Reset()
        {
            Score = 0;
            snake = new Point[3]
            {
            new Point(5, 5),
            new Point(4, 5),
            new Point(3, 5),
            };
            direction = Direction.Right;
            food = GenerateFood();
        }

        public void Tick()
        {
            var head = snake[0];
            var nextHead = new Point(head.X, head.Y);
            switch (direction)
            {
                case Direction.Up:
                    nextHead.Y--;
                    break;
                case Direction.Down:
                    nextHead.Y++;
                    break;
                case Direction.Left:
                    nextHead.X--;
                    break;
                case Direction.Right:
                    nextHead.X++;
                    break;
            }

            if (nextHead.X < 0 || nextHead.X >= width || nextHead.Y < 0 || nextHead.Y >= height)
            {
                Reset();
                return;
            }

            for (int i = 1; i < snake.Length; i++)
            {
                if (snake[i].X == nextHead.X && snake[i].Y == nextHead.Y)
                {
                    Reset();
                    return;
                }
            }

            if (nextHead.X == food.X && nextHead.Y == food.Y)
            {
                Array.Resize(ref snake, snake.Length + 1);
                Score++;
                food = GenerateFood();
            }
            else
            {
                Array.Copy(snake, 1, snake, 2, snake.Length - 2);
            }

            snake[1] = snake[0];
            snake[0] = nextHead;
            pictureBox.Invalidate();
        }

        private void PictureBox_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Up:
                    if (direction != Direction.Down)
                    {
                        direction = Direction.Up;
                    }
                    break;
                case Keys.Down:
                    if (direction != Direction.Up)
                    {
                        direction = Direction.Down;
                    }
                    break;
                case Keys.Left:
                    if (direction != Direction.Right)
                    {
                        direction = Direction.Left;
                    }
                    break;
                case Keys.Right:
                    if (direction != Direction.Left)
                    {
                        direction = Direction.Right;
                    }
                    break;
            }
        }

        private Point GenerateFood()
        {
            var random = new Random();
            return new Point(random.Next(width), random.Next(height));
        }

        private void PictureBox_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(pictureBox.BackColor);

            for (int i = 0; i < snake.Length; i++)
            {
                var brush = i == 0 ? Brushes.Red : Brushes.White;
                e.Graphics.FillRectangle(brush, new Rectangle(snake[i].X * cellSize, snake[i].Y * cellSize, cellSize, cellSize));
            }

            e.Graphics.FillRectangle(Brushes.Green, new Rectangle(food.X * cellSize, food.Y * cellSize, cellSize, cellSize));
        }

        public enum Direction
        {
            Up,
            Down,
            Left,
            Right,
        }

        public Direction Directions
        {
            get => direction;
            set
            {
                if (value != direction)
                {
                    direction = value;
                }
            }
        }
    }
}
