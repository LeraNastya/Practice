﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox34_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Back)
                return;

            if (e.KeyChar >= '0' && e.KeyChar <= '9')
                return;

            if ((',' == e.KeyChar || '.' == e.KeyChar) && ((TextBox)sender).Text.IndexOf(',') == -1)
            {
                e.KeyChar = ',';
                return;
            }

            if (('-' == e.KeyChar) && ((TextBox)sender).Text.Length == 0)
            {
                e.KeyChar = '-';
                return;
            }
            else e.KeyChar = '\0';

            e.KeyChar = '\0';
        }

       

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                richTextBox1.Clear();
                int a = Convert.ToInt32(textBox1.Text);
                Matrix matrix1 = new Matrix(a);
                for (int i = 0; i < a; i++)
                    for (int j = 0; j < a + 1; j++)
                        matrix1.matrix[i, j] = Convert.ToDouble(dataGridView1.Rows[i].Cells[j].Value);
                double[] result = matrix1.Cramer();
                for (int i = 0; i< result.Length; i++)
                {
                    richTextBox1.Text = richTextBox1.Text + "x" + (i + 1) + " = " + result[i] + "\n";
                }

                for (int i = 0; i < a; i++)
                    for (int j = 0; j < a + 1; j++)
                        if (dataGridView1.Rows[i].Cells[j].Value == null)
                            dataGridView1.Rows[i].Cells[j].Value = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button7_Click(object sender, EventArgs e) //Очистить результат
        {
            richTextBox1.Clear();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            int a = Convert.ToInt32(textBox1.Text);

            
            button5.Enabled = true;
            button7.Enabled = true;

            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();

            for (int i = 0; i < a + 1; i++)
            {
                dataGridView1.Columns.Add("", "");
                dataGridView1.Columns[i].Width = 30;
            }
            for (int i = 0; i < a; i++)
            {
                dataGridView1.Rows.Add();
            }
            
            //Покраска
            for (int i = 0; i < a; i++)
            {
                for (int j = 0; j < a + 1; j++)
                {
                    dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.LightBlue;
                }
            }      
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Back)
                return;

            if (e.KeyChar >= '2' && e.KeyChar <= '9')
                return;

            e.KeyChar = '\0';
        }  
    }
}
