﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public class Matrix
    {
        private double[,] _matrix;
        private int size;

        public int Size
        {
            get { return size; }
            set { size = value; }
        }

        public double[,] matrix
        {
            get { return _matrix; }
            set { _matrix = value; }
        }

        /// <summary>
        ///  Конструктор по умолчанию
        /// </summary>
        public Matrix()
        {
            size = 0;
            matrix = new double[0, 0];
        }

        /// <summary>
        ///  Конструктор с параметром
        /// </summary>
        /// <param name="размерность"></param>
        public Matrix(int n)
        {
            size = n;
            matrix = new double[n, n + 1];
        }

        /// <summary>
        ///  Конструктор со значениями
        /// </summary>
        /// <param name="размерность"></param>
        public Matrix(double[,] _matrix)
        {
            if (_matrix.GetLength(0) < 2 || _matrix.GetLength(0) + 1 != _matrix.GetLength(1))
                throw new ArgumentException("Размеры массива не соотвествуют правилам формирования системы уравнений.");
            size = _matrix.GetLength(0);
            matrix = new double[size, size + 1];
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size + 1; j++)
                {
                    matrix[i, j] = _matrix[i, j];
                }
            }
        }

        /// <summary>
        /// Деструктор
        /// </summary>
        ~Matrix() { }

        /// <summary>
        /// Перегрузка операции сложения
        /// </summary>
        /// <param name="1 матрица"></param>
        /// <param name="2 матрица"></param>
        /// <returns></returns>
        public static Matrix operator +(Matrix a, Matrix b)
        {
            if (a.size != b.size)
            {
                throw new Exception("Размеры матриц не совпадают");
            }
            Matrix result = new Matrix(a.size);

            for (int i = 0; i < a.size; i++)
            {
                for (int j = 0; j < a.size + 1; j++)
                {
                    result.matrix[i, j] = a.matrix[i, j] + b.matrix[i, j];
                }
            }
            return result;
        }
        
        /// <summary>
        /// Перегрузка операции вычитания
        /// </summary>
        /// <param name="1 матрица"></param>
        /// <param name="2 матрица"></param>
        /// <returns></returns>
        public static Matrix operator -(Matrix a, Matrix b)
        {
            if (a.size != b.size)
            {
                throw new Exception("Размеры матриц не совпадают");
            }
            Matrix result = new Matrix(a.size);
            for (int i = 0; i < a.size; i++)
            {
                for (int j = 0; j < a.size + 1; j++)
                {
                    result.matrix[i, j] = a.matrix[i, j] - b.matrix[i, j];
                }
            }
            return result;
        }

        /// <summary>
        /// Перегрузка операции умножения строки матрицы на число
        /// </summary>
        /// <param name="матрица"></param>
        /// <param name="число"></param>
        /// <returns></returns>
        public static Matrix operator *(Matrix a, double num)
        {
            Matrix result = new Matrix(a.size);
            for (int i = 0; i < a.size; i++)
            {
                for (int j = 0; j < a.size + 1; j++)
                {
                    result.matrix[i, j] = a.matrix[i, j] * num;
                }
            }
            return result;
        }

        /// <summary>
        /// Перегрузка операции деления строки матрицы на число
        /// </summary>
        /// <param name="матрица"></param>
        /// <param name="число"></param>
        /// <returns></returns>
        public static Matrix operator /(Matrix a, double num)
        {
            if (num == 0)
            {
                throw new Exception("Деление на ноль");
            }
            Matrix result = new Matrix(a.size);
            for (int i = 0; i < a.size; i++)
            {
                for (int j = 0; j < a.size + 1; j++)
                {
                    result.matrix[i, j] = a.matrix[i, j] / num;
                }
            }

            return result;
        }

        /// <summary>
        /// Перегрузка метода ToString
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            string result = "";
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size + 1; j++)
                {
                    result += _matrix[i, j] + " ";
                }
                result += "\n";
            }
            return result;
        }

        /// <summary>
        /// Перегрузка метода Parse
        /// </summary>
        /// <param name="строка"></param>
        /// <returns></returns>
        public static Matrix Parse(string str)
        {
            string[] rows = str.Split('\n');
            int n = rows.Length;
            Matrix result = new Matrix(n);
            for (int i = 0; i < n; i++)
            {
                string[] elements = rows[i].Split(' ');
                for (int j = 0; j < n + 1; j++)
                {
                    result.matrix[i, j] = double.Parse(elements[j]);
                }
            }
            return result;
        }

        /// <summary>
        /// Обмен строк местами
        /// </summary>
        /// <param name="номер 1 строки"></param>
        /// <param name="номер 2 строки"></param>
        public void SwapRows(int i, int j)
        {
            if (i < 0 || i >= size || j < 0 || j >= size)
            {
                throw new Exception("Некорректный индекс строки");
            }
            double[] temp = new double[size + 1];
            for (int k = 0; k < size + 1; k++)
            {
                temp[k] = _matrix[i, k];
                _matrix[i, k] = _matrix[j, k];
                _matrix[j, k] = temp[k];
            }
            double[,] newMatrix = new double[size, size + 1];

        }

        /// <summary>
        /// Удаление пропорциональных строк
        /// </summary>
        public void RemoveProportionalRows()
        {
            for (int i = 0; i < size - 1; i++)
            {
                for (int j = i + 1; j < size; j++)
                {
                    if (IsProportional(i, j))
                    {
                        RemoveRow(j);
                        j--;
                    }
                }
            }
        }

        /// <summary>
        /// Проверка на пропорциональность, т.е. имеют ли строки одинаковые коэффициенты, за исключением постоянного множителя
        /// </summary>
        /// <param name="номер 1 строки"></param>
        /// <param name="номер 2 строки"></param>
        /// <returns></returns>
        private bool IsProportional(int i, int j)
        {
            double ratio = matrix[i, 0] / matrix[j, 0];
            for (int k = 1; k < size; k++)
            {
                if (matrix[j, k] == 0)
                {
                    if (matrix[i, k] != 0)
                    {
                        return false;
                    }
                }
                else if (matrix[i, k] / matrix[j, k] != ratio)
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Удаление строки по индексу, сдвигая все последующие строки вверх, и обновление размера матрицы
        /// </summary>
        /// <param name="номер строки"></param>
        public void RemoveRow(int i)
        {
            for (int j = i; j < size - 1; j++)
            {
                for (int k = 0; k < size + 1; k++)
                {
                    matrix[j, k] = matrix[j + 1, k];
                }
            }
            size--;
            double[,] newMatrix = new double[size, size + 1];
            for (int j = 0; j < size; j++)
            {
                for (int k = 0; k < size + 1; k++)
                {
                    newMatrix[j, k] = matrix[j, k];
                }
            }
            matrix = newMatrix;
        }

        /// <summary>
        /// Проверка всех строк матрицы на нулевые с помощью вспомогательного метода
        /// </summary>
        public void RemoveZeroRows()
        {
            int zeroRowsCount = 0;
            for (int i = 0; i < size; i++)
            {
                if (IsZeroRow(i))
                {
                    zeroRowsCount++;
                }
            }
            if (zeroRowsCount == 0)
            {
                return;
            }
            double[,] newMatrix = new double[size - zeroRowsCount, size + 1];
            int newRowIndex = 0;
            //размер матрицы обновляется, и новый массив присваивается полю matrix
            for (int i = 0; i < size; i++)
            {
                if (!IsZeroRow(i))
                {
                    for (int j = 0; j < size + 1; j++)
                    {
                        newMatrix[newRowIndex, j] = matrix[i, j];
                    }
                    newRowIndex++;
                }
            }
            matrix = newMatrix;
            size -= zeroRowsCount;
        }

        //Проверка, является ли строка нулевой
        public bool IsZeroRow(int i)
        {
            for (int j = 0; j < size; j++)
            {
                if (matrix[i, j] != 0)
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Решение методом Гаусса
        /// </summary>
        /// <returns></returns>
        public double[] Gauss()
        {
            //Проверка как в методе Крамера
            double matrixDet = Determinant(this.matrix, this.size);
            if (matrixDet == 0)
            {
                throw new Exception("Система не имеет однозначного решения.");
            }
            //Код метода Гаусса
            double[,] saveorigin = new double[3,4];
            for (int i = 0; i < saveorigin.GetLength(0); i++)
                for (int j = 0; j < saveorigin.GetLength(1); j++)
                    saveorigin[i, j] = _matrix[i, j];

            // Проверка, что матрица квадратная и размеры корректны
            if (matrix.GetLength(0) != size || matrix.GetLength(1) != size + 1)
            {
                throw new InvalidOperationException("Неправильный размер");
            }

            // Прямой ход - приведение матрицы к верхнетреугольному виду
            for (int i = 0; i < size; i++)
            {
                // Поиск максимального элемента в столбце
                double maxEl = Math.Abs(matrix[i, i]);
                int maxRow = i;
                for (int k = i + 1; k < size; k++)
                {
                    if (Math.Abs(matrix[k, i]) > maxEl)
                    {
                        maxEl = Math.Abs(matrix[k, i]);
                        maxRow = k;
                    }
                }

                // Перестановка строк
                for (int k = i; k < size + 1; k++)
                {
                    double tmp = matrix[maxRow, k];
                    matrix[maxRow, k] = matrix[i, k];
                    matrix[i, k] = tmp;
                }

                // Обнуление элементов ниже главной диагонали
                for (int k = i + 1; k < size; k++)
                {
                    double c = -matrix[k, i] / matrix[i, i];
                    for (int j = i; j < size + 1; j++)
                    {
                        if (i == j)
                        {
                            matrix[k, j] = 0;
                        }
                        else
                        {
                            matrix[k, j] += c * matrix[i, j];
                        }
                    }
                }
            }

            // Обратный ход - решение уравнений
            double[] solution = new double[size];
            for (int i = size - 1; i >= 0; i--)
            {
                solution[i] = matrix[i, size] / matrix[i, i];
                for (int k = i - 1; k >= 0; k--)
                {
                    matrix[k, size] -= matrix[k, i] * solution[i];
                }
            }

            _matrix = saveorigin;

            return solution;
        }

        /// <summary>
        /// Решение методом Крамера
        /// </summary>
        /// <returns></returns>

        public double[] Cramer()
        {
            double[] answers = new double[_matrix.GetLength(0)];
            for (int i = 0; i < _matrix.GetLength(0); i++)
            {
                answers[i] = _matrix[i, _matrix.GetLength(0)];
            }

            double[,] m = new double[_matrix.GetLength(0), _matrix.GetLength(0)];
            for (int i = 0; i < _matrix.GetLength(0); i++)
            {
                for (int j = 0; j < _matrix.GetLength(0); j++)
                {
                    m[i,j] = _matrix[i, j];
                }
            }
            return SloveCramer(m, answers);
        }

        /// <summary>
        /// Алгоритм метода Крамера
        /// </summary>
        /// <param name="массив условий"></param>
        /// <param name="массив значений"></param>
        /// <returns></returns>
        public double[] SloveCramer(double[,] mat, double[] answers)
        {
            int size = mat.GetLength(0);

            double[,] tempMatrix = new double[size, size];
            double matrixDet = Determinant(mat, size);
            if (matrixDet == 0)
            {
                throw new Exception("Определитель матрицы равен нулю, система не имеет однозначного решения.");
            }

            double[] solution = new double[size];
            double matrixDetK;
            for (int i = 0; i < size; i++)
            {
                //tempMatrix = mat;
                for(int n = 0; n < size; n++)
                    for (int m = 0; m < size; m++)
                        tempMatrix[n, m] = mat[n, m];

                for (int j = 0; j < size; j++)
                {
                    tempMatrix[j, i] = answers[j];
                }
                matrixDetK = Determinant(tempMatrix, size);
                solution[i] = matrixDetK / matrixDet;
            }

            return solution;
        }

        /// <summary>
        /// Определение детерминанта
        /// </summary>
        /// <param name="матрица"></param>
        /// <param name="индекс"></param>
        /// <returns></returns>
        private double Determinant(double[,] mat, int n)
        {
            double det = 0;

            if (n == 1)
            {
                return mat[0, 0];
            }
            if (n == 2)
            {
                return mat[0, 0] * mat[1, 1] - mat[0, 1] * mat[1, 0];
            }
            //if (n == 3)
            //{
            //    double p1 = (mat[0, 0] * mat[1, 1] * mat[2, 2]);
            //    double p2 = (mat[0, 1] * mat[1, 2] * mat[2, 0]);
            //    double p3 = (mat[0, 2] * mat[1, 0] * mat[2, 1]);
            //    double m1 = (mat[2, 0] * mat[1, 1] * mat[0, 2]);
            //    double m2 = (mat[0, 1] * mat[1, 0] * mat[2, 2]);
            //    double m3 = (mat[0, 0] * mat[1, 2] * mat[2, 1]);
            //    double p123 = (p1 + p2 + p3);
            //    double m123 = (m1 + m2 + m3);
            //    return p123 - m123;
            //}
            if (n >= 3)
            {
                for (int i = 0; i < n; i++)
                {
                    double[,] subMat = new double[n - 1, n - 1];
                    for (int j = 1; j < n; j++)
                    {
                        for (int k = 0; k < i; k++)
                        {
                            subMat[j - 1, k] = mat[j, k];
                        }
                        for (int k = i + 1; k < n; k++)
                        {
                            subMat[j - 1, k - 1] = mat[j, k];
                        }
                    }
                    det += Math.Pow(-1, i) * mat[0, i] * Determinant(subMat, n - 1);
                }
            }
            return det;
        }
    }
}
