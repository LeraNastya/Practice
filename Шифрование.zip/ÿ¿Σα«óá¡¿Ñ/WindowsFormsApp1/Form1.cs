﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (FileStream fileStream = new FileStream("TestData.txt", FileMode.OpenOrCreate))
                {
                    using (Aes aes = Aes.Create()) // Создание объекта AES для шифрования
                    {
                        byte[] key =
                        {
                            0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
                            0x09, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16
                        };
                        aes.Key = key; // Установка ключа шифрования

                        byte[] iv = aes.IV;
                        fileStream.Write(iv, 0, iv.Length); // Запись вектора инициализации в файл

                        using (CryptoStream cryptoStream = new CryptoStream(fileStream, aes.CreateEncryptor(), CryptoStreamMode.Write)) 
                        {
                            using (StreamWriter encryptWriter = new StreamWriter(cryptoStream)) // Создание объекта для записи в поток
                            {
                                encryptWriter.WriteLine(richTextBox1.Text); // Запись текста из textBox1 в поток
                                //textBox1.Clear();
                            }
                        }
                    }
                }

                richTextBox2.Text = ("Файл был успешно зашифрован.");
            }
            catch (Exception ex)
            {
                richTextBox2.Text = $"Шифрование не удалось. {ex}";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                using (FileStream fileStream = new FileStream("TestData.txt", FileMode.Open)) // Открытие файла для чтения
                {
                    using (Aes aes = Aes.Create()) // Создание объекта AES для расшифровки
                    {
                        byte[] iv = new byte[aes.IV.Length];
                        int numBytesToRead = aes.IV.Length;
                        int numBytesRead = 0;
                        while (numBytesToRead > 0)
                        {
                            int n = fileStream.Read(iv, numBytesRead, numBytesToRead);
                            if (n == 0) break;

                            numBytesRead += n;
                            numBytesToRead -= n;
                        }

                        byte[] key =
                        {
                            0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
                            0x09, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16
                        };

                        using (CryptoStream cryptoStream = new CryptoStream(
                           fileStream,
                           aes.CreateDecryptor(key, iv),
                           CryptoStreamMode.Read)) // Создание потока для расшифровки
                        {
                            using (StreamReader decryptReader = new StreamReader(cryptoStream))
                            {
                                richTextBox2.Text = "";
                                richTextBox2.Text = decryptReader.ReadToEnd(); // Чтение текста из потока и вывод в textBox2
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                richTextBox2.Text = $"Расшифровка не удалась. {ex}";
            }
        }
    }
}