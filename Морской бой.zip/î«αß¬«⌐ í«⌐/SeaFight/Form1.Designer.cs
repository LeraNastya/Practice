﻿namespace SeaFight
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.button75 = new System.Windows.Forms.Button();
            this.button76 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.button82 = new System.Windows.Forms.Button();
            this.button83 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.button85 = new System.Windows.Forms.Button();
            this.button86 = new System.Windows.Forms.Button();
            this.button87 = new System.Windows.Forms.Button();
            this.button88 = new System.Windows.Forms.Button();
            this.button89 = new System.Windows.Forms.Button();
            this.button90 = new System.Windows.Forms.Button();
            this.button91 = new System.Windows.Forms.Button();
            this.button92 = new System.Windows.Forms.Button();
            this.button93 = new System.Windows.Forms.Button();
            this.button94 = new System.Windows.Forms.Button();
            this.button95 = new System.Windows.Forms.Button();
            this.button96 = new System.Windows.Forms.Button();
            this.button97 = new System.Windows.Forms.Button();
            this.button98 = new System.Windows.Forms.Button();
            this.button99 = new System.Windows.Forms.Button();
            this.button100 = new System.Windows.Forms.Button();
            this.button101 = new System.Windows.Forms.Button();
            this.button102 = new System.Windows.Forms.Button();
            this.button103 = new System.Windows.Forms.Button();
            this.button104 = new System.Windows.Forms.Button();
            this.button105 = new System.Windows.Forms.Button();
            this.button106 = new System.Windows.Forms.Button();
            this.button107 = new System.Windows.Forms.Button();
            this.button108 = new System.Windows.Forms.Button();
            this.button109 = new System.Windows.Forms.Button();
            this.button110 = new System.Windows.Forms.Button();
            this.button111 = new System.Windows.Forms.Button();
            this.button112 = new System.Windows.Forms.Button();
            this.button113 = new System.Windows.Forms.Button();
            this.button114 = new System.Windows.Forms.Button();
            this.button115 = new System.Windows.Forms.Button();
            this.button116 = new System.Windows.Forms.Button();
            this.button117 = new System.Windows.Forms.Button();
            this.button118 = new System.Windows.Forms.Button();
            this.button119 = new System.Windows.Forms.Button();
            this.button120 = new System.Windows.Forms.Button();
            this.button121 = new System.Windows.Forms.Button();
            this.button122 = new System.Windows.Forms.Button();
            this.button123 = new System.Windows.Forms.Button();
            this.button124 = new System.Windows.Forms.Button();
            this.button125 = new System.Windows.Forms.Button();
            this.button126 = new System.Windows.Forms.Button();
            this.button127 = new System.Windows.Forms.Button();
            this.button128 = new System.Windows.Forms.Button();
            this.button129 = new System.Windows.Forms.Button();
            this.button130 = new System.Windows.Forms.Button();
            this.button131 = new System.Windows.Forms.Button();
            this.button132 = new System.Windows.Forms.Button();
            this.button133 = new System.Windows.Forms.Button();
            this.button134 = new System.Windows.Forms.Button();
            this.button135 = new System.Windows.Forms.Button();
            this.button136 = new System.Windows.Forms.Button();
            this.button137 = new System.Windows.Forms.Button();
            this.button138 = new System.Windows.Forms.Button();
            this.button139 = new System.Windows.Forms.Button();
            this.button140 = new System.Windows.Forms.Button();
            this.button141 = new System.Windows.Forms.Button();
            this.button142 = new System.Windows.Forms.Button();
            this.button143 = new System.Windows.Forms.Button();
            this.button144 = new System.Windows.Forms.Button();
            this.button145 = new System.Windows.Forms.Button();
            this.button146 = new System.Windows.Forms.Button();
            this.button147 = new System.Windows.Forms.Button();
            this.button148 = new System.Windows.Forms.Button();
            this.button149 = new System.Windows.Forms.Button();
            this.button150 = new System.Windows.Forms.Button();
            this.button151 = new System.Windows.Forms.Button();
            this.button152 = new System.Windows.Forms.Button();
            this.button153 = new System.Windows.Forms.Button();
            this.button154 = new System.Windows.Forms.Button();
            this.button155 = new System.Windows.Forms.Button();
            this.button156 = new System.Windows.Forms.Button();
            this.button157 = new System.Windows.Forms.Button();
            this.button158 = new System.Windows.Forms.Button();
            this.button159 = new System.Windows.Forms.Button();
            this.button160 = new System.Windows.Forms.Button();
            this.button161 = new System.Windows.Forms.Button();
            this.button162 = new System.Windows.Forms.Button();
            this.button163 = new System.Windows.Forms.Button();
            this.button164 = new System.Windows.Forms.Button();
            this.button165 = new System.Windows.Forms.Button();
            this.button166 = new System.Windows.Forms.Button();
            this.button167 = new System.Windows.Forms.Button();
            this.button168 = new System.Windows.Forms.Button();
            this.button169 = new System.Windows.Forms.Button();
            this.button170 = new System.Windows.Forms.Button();
            this.button171 = new System.Windows.Forms.Button();
            this.button172 = new System.Windows.Forms.Button();
            this.button173 = new System.Windows.Forms.Button();
            this.button174 = new System.Windows.Forms.Button();
            this.button175 = new System.Windows.Forms.Button();
            this.button176 = new System.Windows.Forms.Button();
            this.button177 = new System.Windows.Forms.Button();
            this.button178 = new System.Windows.Forms.Button();
            this.button179 = new System.Windows.Forms.Button();
            this.button180 = new System.Windows.Forms.Button();
            this.button181 = new System.Windows.Forms.Button();
            this.button182 = new System.Windows.Forms.Button();
            this.button183 = new System.Windows.Forms.Button();
            this.button184 = new System.Windows.Forms.Button();
            this.button185 = new System.Windows.Forms.Button();
            this.button186 = new System.Windows.Forms.Button();
            this.button187 = new System.Windows.Forms.Button();
            this.button188 = new System.Windows.Forms.Button();
            this.button189 = new System.Windows.Forms.Button();
            this.button190 = new System.Windows.Forms.Button();
            this.button191 = new System.Windows.Forms.Button();
            this.button192 = new System.Windows.Forms.Button();
            this.button193 = new System.Windows.Forms.Button();
            this.button194 = new System.Windows.Forms.Button();
            this.button195 = new System.Windows.Forms.Button();
            this.button196 = new System.Windows.Forms.Button();
            this.button197 = new System.Windows.Forms.Button();
            this.button198 = new System.Windows.Forms.Button();
            this.button199 = new System.Windows.Forms.Button();
            this.button200 = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.ReadRulls = new System.Windows.Forms.Button();
            this.button201 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkGray;
            this.button1.Enabled = false;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button1.Location = new System.Drawing.Point(12, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(39, 39);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DarkGray;
            this.button2.Enabled = false;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button2.Location = new System.Drawing.Point(57, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(39, 39);
            this.button2.TabIndex = 1;
            this.button2.Text = "А";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.DarkGray;
            this.button3.Enabled = false;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button3.Location = new System.Drawing.Point(102, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(39, 39);
            this.button3.TabIndex = 2;
            this.button3.Text = "Б";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.DarkGray;
            this.button4.Enabled = false;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button4.Location = new System.Drawing.Point(147, 12);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(39, 39);
            this.button4.TabIndex = 3;
            this.button4.Text = "В";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.DarkGray;
            this.button5.Enabled = false;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button5.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button5.Location = new System.Drawing.Point(192, 12);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(39, 39);
            this.button5.TabIndex = 4;
            this.button5.Text = "Г";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.DarkGray;
            this.button6.Enabled = false;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button6.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button6.Location = new System.Drawing.Point(237, 12);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(39, 39);
            this.button6.TabIndex = 5;
            this.button6.Text = "Д";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.DarkGray;
            this.button7.Enabled = false;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button7.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button7.Location = new System.Drawing.Point(282, 12);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(39, 39);
            this.button7.TabIndex = 6;
            this.button7.Text = "Е";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.DarkGray;
            this.button8.Enabled = false;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button8.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button8.Location = new System.Drawing.Point(327, 12);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(39, 39);
            this.button8.TabIndex = 7;
            this.button8.Text = "Ж";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.DarkGray;
            this.button9.Enabled = false;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button9.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button9.Location = new System.Drawing.Point(372, 12);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(39, 39);
            this.button9.TabIndex = 8;
            this.button9.Text = "З";
            this.button9.UseVisualStyleBackColor = false;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.DarkGray;
            this.button10.Enabled = false;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button10.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button10.Location = new System.Drawing.Point(417, 12);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(39, 39);
            this.button10.TabIndex = 9;
            this.button10.Text = "И";
            this.button10.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.DarkGray;
            this.button11.Enabled = false;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button11.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button11.Location = new System.Drawing.Point(12, 57);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(39, 39);
            this.button11.TabIndex = 10;
            this.button11.Text = "1";
            this.button11.UseVisualStyleBackColor = false;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.DarkGray;
            this.button12.Enabled = false;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button12.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button12.Location = new System.Drawing.Point(12, 102);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(39, 39);
            this.button12.TabIndex = 11;
            this.button12.Text = "2";
            this.button12.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.DarkGray;
            this.button13.Enabled = false;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button13.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button13.Location = new System.Drawing.Point(12, 147);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(39, 39);
            this.button13.TabIndex = 12;
            this.button13.Text = "3";
            this.button13.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.DarkGray;
            this.button14.Enabled = false;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button14.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button14.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button14.Location = new System.Drawing.Point(12, 192);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(39, 39);
            this.button14.TabIndex = 13;
            this.button14.Text = "4";
            this.button14.UseVisualStyleBackColor = false;
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.DarkGray;
            this.button15.Enabled = false;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button15.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button15.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button15.Location = new System.Drawing.Point(12, 237);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(39, 39);
            this.button15.TabIndex = 14;
            this.button15.Text = "5";
            this.button15.UseVisualStyleBackColor = false;
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.DarkGray;
            this.button16.Enabled = false;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button16.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button16.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button16.Location = new System.Drawing.Point(12, 282);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(39, 39);
            this.button16.TabIndex = 15;
            this.button16.Text = "6";
            this.button16.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.DarkGray;
            this.button17.Enabled = false;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button17.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button17.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button17.Location = new System.Drawing.Point(12, 327);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(39, 39);
            this.button17.TabIndex = 16;
            this.button17.Text = "7";
            this.button17.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.DarkGray;
            this.button18.Enabled = false;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button18.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button18.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button18.Location = new System.Drawing.Point(12, 372);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(39, 39);
            this.button18.TabIndex = 17;
            this.button18.Text = "8";
            this.button18.UseVisualStyleBackColor = false;
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.DarkGray;
            this.button19.Enabled = false;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button19.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button19.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button19.Location = new System.Drawing.Point(12, 417);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(39, 39);
            this.button19.TabIndex = 18;
            this.button19.Text = "9";
            this.button19.UseVisualStyleBackColor = false;
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.White;
            this.button20.Enabled = false;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button20.Location = new System.Drawing.Point(57, 57);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(39, 39);
            this.button20.TabIndex = 19;
            this.button20.Text = " ";
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Click += new System.EventHandler(this.button100_Click);
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.White;
            this.button21.Enabled = false;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button21.Location = new System.Drawing.Point(102, 57);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(39, 39);
            this.button21.TabIndex = 20;
            this.button21.Text = " ";
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Click += new System.EventHandler(this.button100_Click);
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.White;
            this.button22.Enabled = false;
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button22.Location = new System.Drawing.Point(147, 57);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(39, 39);
            this.button22.TabIndex = 21;
            this.button22.Text = " ";
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.button100_Click);
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.White;
            this.button23.Enabled = false;
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button23.Location = new System.Drawing.Point(192, 57);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(39, 39);
            this.button23.TabIndex = 22;
            this.button23.Text = " ";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.button100_Click);
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.White;
            this.button24.Enabled = false;
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button24.Location = new System.Drawing.Point(237, 57);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(39, 39);
            this.button24.TabIndex = 23;
            this.button24.Text = " ";
            this.button24.UseVisualStyleBackColor = false;
            this.button24.Click += new System.EventHandler(this.button100_Click);
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.White;
            this.button25.Enabled = false;
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button25.Location = new System.Drawing.Point(282, 57);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(39, 39);
            this.button25.TabIndex = 24;
            this.button25.Text = " ";
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Click += new System.EventHandler(this.button100_Click);
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.White;
            this.button26.Enabled = false;
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button26.Location = new System.Drawing.Point(327, 57);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(39, 39);
            this.button26.TabIndex = 25;
            this.button26.Text = " ";
            this.button26.UseVisualStyleBackColor = false;
            this.button26.Click += new System.EventHandler(this.button100_Click);
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.White;
            this.button27.Enabled = false;
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button27.Location = new System.Drawing.Point(372, 57);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(39, 39);
            this.button27.TabIndex = 26;
            this.button27.Text = " ";
            this.button27.UseVisualStyleBackColor = false;
            this.button27.Click += new System.EventHandler(this.button100_Click);
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.White;
            this.button28.Enabled = false;
            this.button28.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button28.Location = new System.Drawing.Point(417, 57);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(39, 39);
            this.button28.TabIndex = 27;
            this.button28.Text = " ";
            this.button28.UseVisualStyleBackColor = false;
            this.button28.Click += new System.EventHandler(this.button100_Click);
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.White;
            this.button29.Enabled = false;
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button29.Location = new System.Drawing.Point(57, 102);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(39, 39);
            this.button29.TabIndex = 28;
            this.button29.Text = " ";
            this.button29.UseVisualStyleBackColor = false;
            this.button29.Click += new System.EventHandler(this.button100_Click);
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.White;
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button30.Location = new System.Drawing.Point(102, 102);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(39, 39);
            this.button30.TabIndex = 29;
            this.button30.Text = " ";
            this.button30.UseVisualStyleBackColor = false;
            this.button30.Click += new System.EventHandler(this.button100_Click);
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.Color.White;
            this.button31.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button31.Location = new System.Drawing.Point(147, 102);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(39, 39);
            this.button31.TabIndex = 30;
            this.button31.Text = " ";
            this.button31.UseVisualStyleBackColor = false;
            this.button31.Click += new System.EventHandler(this.button100_Click);
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.Color.White;
            this.button32.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button32.Location = new System.Drawing.Point(192, 102);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(39, 39);
            this.button32.TabIndex = 31;
            this.button32.Text = " ";
            this.button32.UseVisualStyleBackColor = false;
            this.button32.Click += new System.EventHandler(this.button100_Click);
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.Color.White;
            this.button33.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button33.Location = new System.Drawing.Point(237, 102);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(39, 39);
            this.button33.TabIndex = 32;
            this.button33.Text = " ";
            this.button33.UseVisualStyleBackColor = false;
            this.button33.Click += new System.EventHandler(this.button100_Click);
            // 
            // button34
            // 
            this.button34.BackColor = System.Drawing.Color.White;
            this.button34.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button34.Location = new System.Drawing.Point(282, 102);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(39, 39);
            this.button34.TabIndex = 33;
            this.button34.Text = " ";
            this.button34.UseVisualStyleBackColor = false;
            this.button34.Click += new System.EventHandler(this.button100_Click);
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.Color.White;
            this.button35.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button35.Location = new System.Drawing.Point(327, 102);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(39, 39);
            this.button35.TabIndex = 34;
            this.button35.Text = " ";
            this.button35.UseVisualStyleBackColor = false;
            this.button35.Click += new System.EventHandler(this.button100_Click);
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.Color.White;
            this.button36.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button36.Location = new System.Drawing.Point(372, 102);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(39, 39);
            this.button36.TabIndex = 35;
            this.button36.Text = " ";
            this.button36.UseVisualStyleBackColor = false;
            this.button36.Click += new System.EventHandler(this.button100_Click);
            // 
            // button37
            // 
            this.button37.BackColor = System.Drawing.Color.White;
            this.button37.Enabled = false;
            this.button37.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button37.Location = new System.Drawing.Point(417, 102);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(39, 39);
            this.button37.TabIndex = 36;
            this.button37.Text = " ";
            this.button37.UseVisualStyleBackColor = false;
            this.button37.Click += new System.EventHandler(this.button100_Click);
            // 
            // button38
            // 
            this.button38.BackColor = System.Drawing.Color.White;
            this.button38.Enabled = false;
            this.button38.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button38.Location = new System.Drawing.Point(57, 147);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(39, 39);
            this.button38.TabIndex = 37;
            this.button38.Text = " ";
            this.button38.UseVisualStyleBackColor = false;
            this.button38.Click += new System.EventHandler(this.button100_Click);
            // 
            // button39
            // 
            this.button39.BackColor = System.Drawing.Color.White;
            this.button39.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button39.Location = new System.Drawing.Point(102, 147);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(39, 39);
            this.button39.TabIndex = 38;
            this.button39.Text = " ";
            this.button39.UseVisualStyleBackColor = false;
            this.button39.Click += new System.EventHandler(this.button100_Click);
            // 
            // button40
            // 
            this.button40.BackColor = System.Drawing.Color.White;
            this.button40.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button40.Location = new System.Drawing.Point(147, 147);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(39, 39);
            this.button40.TabIndex = 39;
            this.button40.Text = " ";
            this.button40.UseVisualStyleBackColor = false;
            this.button40.Click += new System.EventHandler(this.button100_Click);
            // 
            // button41
            // 
            this.button41.BackColor = System.Drawing.Color.White;
            this.button41.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button41.Location = new System.Drawing.Point(192, 147);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(39, 39);
            this.button41.TabIndex = 40;
            this.button41.Text = " ";
            this.button41.UseVisualStyleBackColor = false;
            this.button41.Click += new System.EventHandler(this.button100_Click);
            // 
            // button42
            // 
            this.button42.BackColor = System.Drawing.Color.White;
            this.button42.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button42.Location = new System.Drawing.Point(237, 147);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(39, 39);
            this.button42.TabIndex = 41;
            this.button42.Text = " ";
            this.button42.UseVisualStyleBackColor = false;
            this.button42.Click += new System.EventHandler(this.button100_Click);
            // 
            // button43
            // 
            this.button43.BackColor = System.Drawing.Color.White;
            this.button43.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button43.Location = new System.Drawing.Point(282, 147);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(39, 39);
            this.button43.TabIndex = 42;
            this.button43.Text = " ";
            this.button43.UseVisualStyleBackColor = false;
            this.button43.Click += new System.EventHandler(this.button100_Click);
            // 
            // button44
            // 
            this.button44.BackColor = System.Drawing.Color.White;
            this.button44.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button44.Location = new System.Drawing.Point(327, 147);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(39, 39);
            this.button44.TabIndex = 43;
            this.button44.Text = " ";
            this.button44.UseVisualStyleBackColor = false;
            this.button44.Click += new System.EventHandler(this.button100_Click);
            // 
            // button45
            // 
            this.button45.BackColor = System.Drawing.Color.White;
            this.button45.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button45.Location = new System.Drawing.Point(372, 147);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(39, 39);
            this.button45.TabIndex = 44;
            this.button45.Text = " ";
            this.button45.UseVisualStyleBackColor = false;
            this.button45.Click += new System.EventHandler(this.button100_Click);
            // 
            // button46
            // 
            this.button46.BackColor = System.Drawing.Color.White;
            this.button46.Enabled = false;
            this.button46.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button46.Location = new System.Drawing.Point(417, 147);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(39, 39);
            this.button46.TabIndex = 45;
            this.button46.Text = " ";
            this.button46.UseVisualStyleBackColor = false;
            this.button46.Click += new System.EventHandler(this.button100_Click);
            // 
            // button47
            // 
            this.button47.BackColor = System.Drawing.Color.White;
            this.button47.Enabled = false;
            this.button47.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button47.Location = new System.Drawing.Point(57, 192);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(39, 39);
            this.button47.TabIndex = 46;
            this.button47.Text = " ";
            this.button47.UseVisualStyleBackColor = false;
            this.button47.Click += new System.EventHandler(this.button100_Click);
            // 
            // button48
            // 
            this.button48.BackColor = System.Drawing.Color.White;
            this.button48.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button48.Location = new System.Drawing.Point(102, 192);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(39, 39);
            this.button48.TabIndex = 47;
            this.button48.Text = " ";
            this.button48.UseVisualStyleBackColor = false;
            this.button48.Click += new System.EventHandler(this.button100_Click);
            // 
            // button49
            // 
            this.button49.BackColor = System.Drawing.Color.White;
            this.button49.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button49.Location = new System.Drawing.Point(147, 192);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(39, 39);
            this.button49.TabIndex = 48;
            this.button49.Text = " ";
            this.button49.UseVisualStyleBackColor = false;
            this.button49.Click += new System.EventHandler(this.button100_Click);
            // 
            // button50
            // 
            this.button50.BackColor = System.Drawing.Color.White;
            this.button50.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button50.Location = new System.Drawing.Point(192, 192);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(39, 39);
            this.button50.TabIndex = 49;
            this.button50.Text = " ";
            this.button50.UseVisualStyleBackColor = false;
            this.button50.Click += new System.EventHandler(this.button100_Click);
            // 
            // button51
            // 
            this.button51.BackColor = System.Drawing.Color.White;
            this.button51.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button51.Location = new System.Drawing.Point(237, 192);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(39, 39);
            this.button51.TabIndex = 50;
            this.button51.Text = " ";
            this.button51.UseVisualStyleBackColor = false;
            this.button51.Click += new System.EventHandler(this.button100_Click);
            // 
            // button52
            // 
            this.button52.BackColor = System.Drawing.Color.White;
            this.button52.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button52.Location = new System.Drawing.Point(282, 192);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(39, 39);
            this.button52.TabIndex = 51;
            this.button52.Text = " ";
            this.button52.UseVisualStyleBackColor = false;
            this.button52.Click += new System.EventHandler(this.button100_Click);
            // 
            // button53
            // 
            this.button53.BackColor = System.Drawing.Color.White;
            this.button53.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button53.Location = new System.Drawing.Point(327, 192);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(39, 39);
            this.button53.TabIndex = 52;
            this.button53.Text = " ";
            this.button53.UseVisualStyleBackColor = false;
            this.button53.Click += new System.EventHandler(this.button100_Click);
            // 
            // button54
            // 
            this.button54.BackColor = System.Drawing.Color.White;
            this.button54.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button54.Location = new System.Drawing.Point(372, 192);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(39, 39);
            this.button54.TabIndex = 53;
            this.button54.Text = " ";
            this.button54.UseVisualStyleBackColor = false;
            this.button54.Click += new System.EventHandler(this.button100_Click);
            // 
            // button55
            // 
            this.button55.BackColor = System.Drawing.Color.White;
            this.button55.Enabled = false;
            this.button55.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button55.Location = new System.Drawing.Point(417, 192);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(39, 39);
            this.button55.TabIndex = 54;
            this.button55.Text = " ";
            this.button55.UseVisualStyleBackColor = false;
            this.button55.Click += new System.EventHandler(this.button100_Click);
            // 
            // button56
            // 
            this.button56.BackColor = System.Drawing.Color.White;
            this.button56.Enabled = false;
            this.button56.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button56.Location = new System.Drawing.Point(57, 237);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(39, 39);
            this.button56.TabIndex = 55;
            this.button56.Text = " ";
            this.button56.UseVisualStyleBackColor = false;
            this.button56.Click += new System.EventHandler(this.button100_Click);
            // 
            // button57
            // 
            this.button57.BackColor = System.Drawing.Color.White;
            this.button57.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button57.Location = new System.Drawing.Point(102, 237);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(39, 39);
            this.button57.TabIndex = 56;
            this.button57.Text = " ";
            this.button57.UseVisualStyleBackColor = false;
            this.button57.Click += new System.EventHandler(this.button100_Click);
            // 
            // button58
            // 
            this.button58.BackColor = System.Drawing.Color.White;
            this.button58.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button58.Location = new System.Drawing.Point(147, 237);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(39, 39);
            this.button58.TabIndex = 57;
            this.button58.Text = " ";
            this.button58.UseVisualStyleBackColor = false;
            this.button58.Click += new System.EventHandler(this.button100_Click);
            // 
            // button59
            // 
            this.button59.BackColor = System.Drawing.Color.White;
            this.button59.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button59.Location = new System.Drawing.Point(192, 237);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(39, 39);
            this.button59.TabIndex = 58;
            this.button59.Text = " ";
            this.button59.UseVisualStyleBackColor = false;
            this.button59.Click += new System.EventHandler(this.button100_Click);
            // 
            // button60
            // 
            this.button60.BackColor = System.Drawing.Color.White;
            this.button60.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button60.Location = new System.Drawing.Point(237, 237);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(39, 39);
            this.button60.TabIndex = 59;
            this.button60.Text = " ";
            this.button60.UseVisualStyleBackColor = false;
            this.button60.Click += new System.EventHandler(this.button100_Click);
            // 
            // button61
            // 
            this.button61.BackColor = System.Drawing.Color.White;
            this.button61.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button61.Location = new System.Drawing.Point(282, 237);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(39, 39);
            this.button61.TabIndex = 60;
            this.button61.Text = " ";
            this.button61.UseVisualStyleBackColor = false;
            this.button61.Click += new System.EventHandler(this.button100_Click);
            // 
            // button62
            // 
            this.button62.BackColor = System.Drawing.Color.White;
            this.button62.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button62.Location = new System.Drawing.Point(327, 237);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(39, 39);
            this.button62.TabIndex = 61;
            this.button62.Text = " ";
            this.button62.UseVisualStyleBackColor = false;
            this.button62.Click += new System.EventHandler(this.button100_Click);
            // 
            // button63
            // 
            this.button63.BackColor = System.Drawing.Color.White;
            this.button63.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button63.Location = new System.Drawing.Point(372, 237);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(39, 39);
            this.button63.TabIndex = 62;
            this.button63.Text = " ";
            this.button63.UseVisualStyleBackColor = false;
            this.button63.Click += new System.EventHandler(this.button100_Click);
            // 
            // button64
            // 
            this.button64.BackColor = System.Drawing.Color.White;
            this.button64.Enabled = false;
            this.button64.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button64.Location = new System.Drawing.Point(417, 237);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(39, 39);
            this.button64.TabIndex = 63;
            this.button64.Text = " ";
            this.button64.UseVisualStyleBackColor = false;
            this.button64.Click += new System.EventHandler(this.button100_Click);
            // 
            // button65
            // 
            this.button65.BackColor = System.Drawing.Color.White;
            this.button65.Enabled = false;
            this.button65.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button65.Location = new System.Drawing.Point(57, 282);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(39, 39);
            this.button65.TabIndex = 64;
            this.button65.Text = " ";
            this.button65.UseVisualStyleBackColor = false;
            this.button65.Click += new System.EventHandler(this.button100_Click);
            // 
            // button66
            // 
            this.button66.BackColor = System.Drawing.Color.White;
            this.button66.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button66.Location = new System.Drawing.Point(102, 282);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(39, 39);
            this.button66.TabIndex = 65;
            this.button66.Text = " ";
            this.button66.UseVisualStyleBackColor = false;
            this.button66.Click += new System.EventHandler(this.button100_Click);
            // 
            // button67
            // 
            this.button67.BackColor = System.Drawing.Color.White;
            this.button67.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button67.Location = new System.Drawing.Point(147, 282);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(39, 39);
            this.button67.TabIndex = 66;
            this.button67.Text = " ";
            this.button67.UseVisualStyleBackColor = false;
            this.button67.Click += new System.EventHandler(this.button100_Click);
            // 
            // button68
            // 
            this.button68.BackColor = System.Drawing.Color.White;
            this.button68.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button68.Location = new System.Drawing.Point(192, 282);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(39, 39);
            this.button68.TabIndex = 67;
            this.button68.Text = " ";
            this.button68.UseVisualStyleBackColor = false;
            this.button68.Click += new System.EventHandler(this.button100_Click);
            // 
            // button69
            // 
            this.button69.BackColor = System.Drawing.Color.White;
            this.button69.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button69.Location = new System.Drawing.Point(237, 282);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(39, 39);
            this.button69.TabIndex = 68;
            this.button69.Text = " ";
            this.button69.UseVisualStyleBackColor = false;
            this.button69.Click += new System.EventHandler(this.button100_Click);
            // 
            // button70
            // 
            this.button70.BackColor = System.Drawing.Color.White;
            this.button70.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button70.Location = new System.Drawing.Point(282, 282);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(39, 39);
            this.button70.TabIndex = 69;
            this.button70.Text = " ";
            this.button70.UseVisualStyleBackColor = false;
            this.button70.Click += new System.EventHandler(this.button100_Click);
            // 
            // button71
            // 
            this.button71.BackColor = System.Drawing.Color.White;
            this.button71.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button71.Location = new System.Drawing.Point(327, 282);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(39, 39);
            this.button71.TabIndex = 70;
            this.button71.Text = " ";
            this.button71.UseVisualStyleBackColor = false;
            this.button71.Click += new System.EventHandler(this.button100_Click);
            // 
            // button72
            // 
            this.button72.BackColor = System.Drawing.Color.White;
            this.button72.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button72.Location = new System.Drawing.Point(372, 282);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(39, 39);
            this.button72.TabIndex = 71;
            this.button72.Text = " ";
            this.button72.UseVisualStyleBackColor = false;
            this.button72.Click += new System.EventHandler(this.button100_Click);
            // 
            // button73
            // 
            this.button73.BackColor = System.Drawing.Color.White;
            this.button73.Enabled = false;
            this.button73.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button73.Location = new System.Drawing.Point(417, 282);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(39, 39);
            this.button73.TabIndex = 72;
            this.button73.Text = " ";
            this.button73.UseVisualStyleBackColor = false;
            this.button73.Click += new System.EventHandler(this.button100_Click);
            // 
            // button74
            // 
            this.button74.BackColor = System.Drawing.Color.White;
            this.button74.Enabled = false;
            this.button74.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button74.Location = new System.Drawing.Point(57, 327);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(39, 39);
            this.button74.TabIndex = 73;
            this.button74.Text = " ";
            this.button74.UseVisualStyleBackColor = false;
            this.button74.Click += new System.EventHandler(this.button100_Click);
            // 
            // button75
            // 
            this.button75.BackColor = System.Drawing.Color.White;
            this.button75.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button75.Location = new System.Drawing.Point(102, 327);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(39, 39);
            this.button75.TabIndex = 74;
            this.button75.Text = " ";
            this.button75.UseVisualStyleBackColor = false;
            this.button75.Click += new System.EventHandler(this.button100_Click);
            // 
            // button76
            // 
            this.button76.BackColor = System.Drawing.Color.White;
            this.button76.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button76.Location = new System.Drawing.Point(147, 327);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(39, 39);
            this.button76.TabIndex = 75;
            this.button76.Text = " ";
            this.button76.UseVisualStyleBackColor = false;
            this.button76.Click += new System.EventHandler(this.button100_Click);
            // 
            // button77
            // 
            this.button77.BackColor = System.Drawing.Color.White;
            this.button77.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button77.Location = new System.Drawing.Point(192, 327);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(39, 39);
            this.button77.TabIndex = 76;
            this.button77.Text = " ";
            this.button77.UseVisualStyleBackColor = false;
            this.button77.Click += new System.EventHandler(this.button100_Click);
            // 
            // button78
            // 
            this.button78.BackColor = System.Drawing.Color.White;
            this.button78.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button78.Location = new System.Drawing.Point(237, 327);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(39, 39);
            this.button78.TabIndex = 77;
            this.button78.Text = " ";
            this.button78.UseVisualStyleBackColor = false;
            this.button78.Click += new System.EventHandler(this.button100_Click);
            // 
            // button79
            // 
            this.button79.BackColor = System.Drawing.Color.White;
            this.button79.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button79.Location = new System.Drawing.Point(282, 327);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(39, 39);
            this.button79.TabIndex = 78;
            this.button79.Text = " ";
            this.button79.UseVisualStyleBackColor = false;
            this.button79.Click += new System.EventHandler(this.button100_Click);
            // 
            // button80
            // 
            this.button80.BackColor = System.Drawing.Color.White;
            this.button80.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button80.Location = new System.Drawing.Point(327, 327);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(39, 39);
            this.button80.TabIndex = 79;
            this.button80.Text = " ";
            this.button80.UseVisualStyleBackColor = false;
            this.button80.Click += new System.EventHandler(this.button100_Click);
            // 
            // button81
            // 
            this.button81.BackColor = System.Drawing.Color.White;
            this.button81.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button81.Location = new System.Drawing.Point(372, 327);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(39, 39);
            this.button81.TabIndex = 80;
            this.button81.Text = " ";
            this.button81.UseVisualStyleBackColor = false;
            this.button81.Click += new System.EventHandler(this.button100_Click);
            // 
            // button82
            // 
            this.button82.BackColor = System.Drawing.Color.White;
            this.button82.Enabled = false;
            this.button82.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button82.Location = new System.Drawing.Point(417, 327);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(39, 39);
            this.button82.TabIndex = 81;
            this.button82.Text = " ";
            this.button82.UseVisualStyleBackColor = false;
            this.button82.Click += new System.EventHandler(this.button100_Click);
            // 
            // button83
            // 
            this.button83.BackColor = System.Drawing.Color.White;
            this.button83.Enabled = false;
            this.button83.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button83.Location = new System.Drawing.Point(57, 372);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(39, 39);
            this.button83.TabIndex = 82;
            this.button83.Text = " ";
            this.button83.UseVisualStyleBackColor = false;
            this.button83.Click += new System.EventHandler(this.button100_Click);
            // 
            // button84
            // 
            this.button84.BackColor = System.Drawing.Color.White;
            this.button84.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button84.Location = new System.Drawing.Point(102, 372);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(39, 39);
            this.button84.TabIndex = 83;
            this.button84.Text = " ";
            this.button84.UseVisualStyleBackColor = false;
            this.button84.Click += new System.EventHandler(this.button100_Click);
            // 
            // button85
            // 
            this.button85.BackColor = System.Drawing.Color.White;
            this.button85.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button85.Location = new System.Drawing.Point(147, 372);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(39, 39);
            this.button85.TabIndex = 84;
            this.button85.Text = " ";
            this.button85.UseVisualStyleBackColor = false;
            this.button85.Click += new System.EventHandler(this.button100_Click);
            // 
            // button86
            // 
            this.button86.BackColor = System.Drawing.Color.White;
            this.button86.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button86.Location = new System.Drawing.Point(192, 372);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(39, 39);
            this.button86.TabIndex = 85;
            this.button86.Text = " ";
            this.button86.UseVisualStyleBackColor = false;
            this.button86.Click += new System.EventHandler(this.button100_Click);
            // 
            // button87
            // 
            this.button87.BackColor = System.Drawing.Color.White;
            this.button87.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button87.Location = new System.Drawing.Point(237, 372);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(39, 39);
            this.button87.TabIndex = 86;
            this.button87.Text = " ";
            this.button87.UseVisualStyleBackColor = false;
            this.button87.Click += new System.EventHandler(this.button100_Click);
            // 
            // button88
            // 
            this.button88.BackColor = System.Drawing.Color.White;
            this.button88.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button88.Location = new System.Drawing.Point(282, 372);
            this.button88.Name = "button88";
            this.button88.Size = new System.Drawing.Size(39, 39);
            this.button88.TabIndex = 87;
            this.button88.Text = " ";
            this.button88.UseVisualStyleBackColor = false;
            this.button88.Click += new System.EventHandler(this.button100_Click);
            // 
            // button89
            // 
            this.button89.BackColor = System.Drawing.Color.White;
            this.button89.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button89.Location = new System.Drawing.Point(327, 372);
            this.button89.Name = "button89";
            this.button89.Size = new System.Drawing.Size(39, 39);
            this.button89.TabIndex = 88;
            this.button89.Text = " ";
            this.button89.UseVisualStyleBackColor = false;
            this.button89.Click += new System.EventHandler(this.button100_Click);
            // 
            // button90
            // 
            this.button90.BackColor = System.Drawing.Color.White;
            this.button90.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button90.Location = new System.Drawing.Point(372, 372);
            this.button90.Name = "button90";
            this.button90.Size = new System.Drawing.Size(39, 39);
            this.button90.TabIndex = 89;
            this.button90.Text = " ";
            this.button90.UseVisualStyleBackColor = false;
            this.button90.Click += new System.EventHandler(this.button100_Click);
            // 
            // button91
            // 
            this.button91.BackColor = System.Drawing.Color.White;
            this.button91.Enabled = false;
            this.button91.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button91.Location = new System.Drawing.Point(417, 372);
            this.button91.Name = "button91";
            this.button91.Size = new System.Drawing.Size(39, 39);
            this.button91.TabIndex = 90;
            this.button91.Text = " ";
            this.button91.UseVisualStyleBackColor = false;
            this.button91.Click += new System.EventHandler(this.button100_Click);
            // 
            // button92
            // 
            this.button92.BackColor = System.Drawing.Color.White;
            this.button92.Enabled = false;
            this.button92.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button92.Location = new System.Drawing.Point(57, 417);
            this.button92.Name = "button92";
            this.button92.Size = new System.Drawing.Size(39, 39);
            this.button92.TabIndex = 91;
            this.button92.Text = " ";
            this.button92.UseVisualStyleBackColor = false;
            this.button92.Click += new System.EventHandler(this.button100_Click);
            // 
            // button93
            // 
            this.button93.BackColor = System.Drawing.Color.White;
            this.button93.Enabled = false;
            this.button93.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button93.Location = new System.Drawing.Point(102, 417);
            this.button93.Name = "button93";
            this.button93.Size = new System.Drawing.Size(39, 39);
            this.button93.TabIndex = 92;
            this.button93.Text = " ";
            this.button93.UseVisualStyleBackColor = false;
            this.button93.Click += new System.EventHandler(this.button100_Click);
            // 
            // button94
            // 
            this.button94.BackColor = System.Drawing.Color.White;
            this.button94.Enabled = false;
            this.button94.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button94.Location = new System.Drawing.Point(147, 417);
            this.button94.Name = "button94";
            this.button94.Size = new System.Drawing.Size(39, 39);
            this.button94.TabIndex = 93;
            this.button94.Text = " ";
            this.button94.UseVisualStyleBackColor = false;
            this.button94.Click += new System.EventHandler(this.button100_Click);
            // 
            // button95
            // 
            this.button95.BackColor = System.Drawing.Color.White;
            this.button95.Enabled = false;
            this.button95.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button95.Location = new System.Drawing.Point(192, 417);
            this.button95.Name = "button95";
            this.button95.Size = new System.Drawing.Size(39, 39);
            this.button95.TabIndex = 94;
            this.button95.Text = " ";
            this.button95.UseVisualStyleBackColor = false;
            this.button95.Click += new System.EventHandler(this.button100_Click);
            // 
            // button96
            // 
            this.button96.BackColor = System.Drawing.Color.White;
            this.button96.Enabled = false;
            this.button96.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button96.Location = new System.Drawing.Point(237, 417);
            this.button96.Name = "button96";
            this.button96.Size = new System.Drawing.Size(39, 39);
            this.button96.TabIndex = 95;
            this.button96.Text = " ";
            this.button96.UseVisualStyleBackColor = false;
            this.button96.Click += new System.EventHandler(this.button100_Click);
            // 
            // button97
            // 
            this.button97.BackColor = System.Drawing.Color.White;
            this.button97.Enabled = false;
            this.button97.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button97.Location = new System.Drawing.Point(282, 417);
            this.button97.Name = "button97";
            this.button97.Size = new System.Drawing.Size(39, 39);
            this.button97.TabIndex = 96;
            this.button97.Text = " ";
            this.button97.UseVisualStyleBackColor = false;
            this.button97.Click += new System.EventHandler(this.button100_Click);
            // 
            // button98
            // 
            this.button98.BackColor = System.Drawing.Color.White;
            this.button98.Enabled = false;
            this.button98.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button98.Location = new System.Drawing.Point(327, 417);
            this.button98.Name = "button98";
            this.button98.Size = new System.Drawing.Size(39, 39);
            this.button98.TabIndex = 97;
            this.button98.Text = " ";
            this.button98.UseVisualStyleBackColor = false;
            this.button98.Click += new System.EventHandler(this.button100_Click);
            // 
            // button99
            // 
            this.button99.BackColor = System.Drawing.Color.White;
            this.button99.Enabled = false;
            this.button99.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button99.Location = new System.Drawing.Point(372, 417);
            this.button99.Name = "button99";
            this.button99.Size = new System.Drawing.Size(39, 39);
            this.button99.TabIndex = 98;
            this.button99.Text = " ";
            this.button99.UseVisualStyleBackColor = false;
            this.button99.Click += new System.EventHandler(this.button100_Click);
            // 
            // button100
            // 
            this.button100.BackColor = System.Drawing.Color.White;
            this.button100.Enabled = false;
            this.button100.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button100.Location = new System.Drawing.Point(417, 417);
            this.button100.Name = "button100";
            this.button100.Size = new System.Drawing.Size(39, 39);
            this.button100.TabIndex = 99;
            this.button100.Text = " ";
            this.button100.UseVisualStyleBackColor = false;
            this.button100.Click += new System.EventHandler(this.button100_Click);
            // 
            // button101
            // 
            this.button101.BackColor = System.Drawing.Color.DarkGray;
            this.button101.Enabled = false;
            this.button101.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button101.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button101.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button101.Location = new System.Drawing.Point(547, 12);
            this.button101.Name = "button101";
            this.button101.Size = new System.Drawing.Size(39, 39);
            this.button101.TabIndex = 100;
            this.button101.UseVisualStyleBackColor = false;
            // 
            // button102
            // 
            this.button102.BackColor = System.Drawing.Color.DarkGray;
            this.button102.Enabled = false;
            this.button102.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button102.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button102.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button102.Location = new System.Drawing.Point(592, 12);
            this.button102.Name = "button102";
            this.button102.Size = new System.Drawing.Size(39, 39);
            this.button102.TabIndex = 101;
            this.button102.Text = "А";
            this.button102.UseVisualStyleBackColor = false;
            // 
            // button103
            // 
            this.button103.BackColor = System.Drawing.Color.DarkGray;
            this.button103.Enabled = false;
            this.button103.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button103.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button103.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button103.Location = new System.Drawing.Point(637, 12);
            this.button103.Name = "button103";
            this.button103.Size = new System.Drawing.Size(39, 39);
            this.button103.TabIndex = 102;
            this.button103.Text = "Б";
            this.button103.UseVisualStyleBackColor = false;
            // 
            // button104
            // 
            this.button104.BackColor = System.Drawing.Color.DarkGray;
            this.button104.Enabled = false;
            this.button104.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button104.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button104.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button104.Location = new System.Drawing.Point(682, 12);
            this.button104.Name = "button104";
            this.button104.Size = new System.Drawing.Size(39, 39);
            this.button104.TabIndex = 103;
            this.button104.Text = "В";
            this.button104.UseVisualStyleBackColor = false;
            // 
            // button105
            // 
            this.button105.BackColor = System.Drawing.Color.DarkGray;
            this.button105.Enabled = false;
            this.button105.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button105.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button105.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button105.Location = new System.Drawing.Point(727, 12);
            this.button105.Name = "button105";
            this.button105.Size = new System.Drawing.Size(39, 39);
            this.button105.TabIndex = 104;
            this.button105.Text = "Г";
            this.button105.UseVisualStyleBackColor = false;
            // 
            // button106
            // 
            this.button106.BackColor = System.Drawing.Color.DarkGray;
            this.button106.Enabled = false;
            this.button106.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button106.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button106.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button106.Location = new System.Drawing.Point(772, 12);
            this.button106.Name = "button106";
            this.button106.Size = new System.Drawing.Size(39, 39);
            this.button106.TabIndex = 105;
            this.button106.Text = "Д";
            this.button106.UseVisualStyleBackColor = false;
            // 
            // button107
            // 
            this.button107.BackColor = System.Drawing.Color.DarkGray;
            this.button107.Enabled = false;
            this.button107.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button107.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button107.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button107.Location = new System.Drawing.Point(817, 12);
            this.button107.Name = "button107";
            this.button107.Size = new System.Drawing.Size(39, 39);
            this.button107.TabIndex = 106;
            this.button107.Text = "Е";
            this.button107.UseVisualStyleBackColor = false;
            // 
            // button108
            // 
            this.button108.BackColor = System.Drawing.Color.DarkGray;
            this.button108.Enabled = false;
            this.button108.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button108.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button108.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button108.Location = new System.Drawing.Point(862, 12);
            this.button108.Name = "button108";
            this.button108.Size = new System.Drawing.Size(39, 39);
            this.button108.TabIndex = 107;
            this.button108.Text = "Ж";
            this.button108.UseVisualStyleBackColor = false;
            // 
            // button109
            // 
            this.button109.BackColor = System.Drawing.Color.DarkGray;
            this.button109.Enabled = false;
            this.button109.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button109.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button109.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button109.Location = new System.Drawing.Point(907, 12);
            this.button109.Name = "button109";
            this.button109.Size = new System.Drawing.Size(39, 39);
            this.button109.TabIndex = 108;
            this.button109.Text = "З";
            this.button109.UseVisualStyleBackColor = false;
            // 
            // button110
            // 
            this.button110.BackColor = System.Drawing.Color.DarkGray;
            this.button110.Enabled = false;
            this.button110.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button110.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button110.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button110.Location = new System.Drawing.Point(952, 12);
            this.button110.Name = "button110";
            this.button110.Size = new System.Drawing.Size(39, 39);
            this.button110.TabIndex = 109;
            this.button110.Text = "И";
            this.button110.UseVisualStyleBackColor = false;
            // 
            // button111
            // 
            this.button111.BackColor = System.Drawing.Color.DarkGray;
            this.button111.Enabled = false;
            this.button111.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button111.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button111.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button111.Location = new System.Drawing.Point(547, 57);
            this.button111.Name = "button111";
            this.button111.Size = new System.Drawing.Size(39, 39);
            this.button111.TabIndex = 110;
            this.button111.Text = "1";
            this.button111.UseVisualStyleBackColor = false;
            // 
            // button112
            // 
            this.button112.BackColor = System.Drawing.Color.DarkGray;
            this.button112.Enabled = false;
            this.button112.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button112.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button112.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button112.Location = new System.Drawing.Point(547, 102);
            this.button112.Name = "button112";
            this.button112.Size = new System.Drawing.Size(39, 39);
            this.button112.TabIndex = 111;
            this.button112.Text = "2";
            this.button112.UseVisualStyleBackColor = false;
            // 
            // button113
            // 
            this.button113.BackColor = System.Drawing.Color.DarkGray;
            this.button113.Enabled = false;
            this.button113.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button113.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button113.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button113.Location = new System.Drawing.Point(547, 147);
            this.button113.Name = "button113";
            this.button113.Size = new System.Drawing.Size(39, 39);
            this.button113.TabIndex = 112;
            this.button113.Text = "3";
            this.button113.UseVisualStyleBackColor = false;
            // 
            // button114
            // 
            this.button114.BackColor = System.Drawing.Color.DarkGray;
            this.button114.Enabled = false;
            this.button114.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button114.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button114.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button114.Location = new System.Drawing.Point(547, 192);
            this.button114.Name = "button114";
            this.button114.Size = new System.Drawing.Size(39, 39);
            this.button114.TabIndex = 113;
            this.button114.Text = "4";
            this.button114.UseVisualStyleBackColor = false;
            // 
            // button115
            // 
            this.button115.BackColor = System.Drawing.Color.DarkGray;
            this.button115.Enabled = false;
            this.button115.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button115.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button115.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button115.Location = new System.Drawing.Point(547, 237);
            this.button115.Name = "button115";
            this.button115.Size = new System.Drawing.Size(39, 39);
            this.button115.TabIndex = 114;
            this.button115.Text = "5";
            this.button115.UseVisualStyleBackColor = false;
            // 
            // button116
            // 
            this.button116.BackColor = System.Drawing.Color.DarkGray;
            this.button116.Enabled = false;
            this.button116.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button116.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button116.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button116.Location = new System.Drawing.Point(547, 282);
            this.button116.Name = "button116";
            this.button116.Size = new System.Drawing.Size(39, 39);
            this.button116.TabIndex = 115;
            this.button116.Text = "6";
            this.button116.UseVisualStyleBackColor = false;
            // 
            // button117
            // 
            this.button117.BackColor = System.Drawing.Color.DarkGray;
            this.button117.Enabled = false;
            this.button117.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button117.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button117.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button117.Location = new System.Drawing.Point(547, 327);
            this.button117.Name = "button117";
            this.button117.Size = new System.Drawing.Size(39, 39);
            this.button117.TabIndex = 116;
            this.button117.Text = "7";
            this.button117.UseVisualStyleBackColor = false;
            // 
            // button118
            // 
            this.button118.BackColor = System.Drawing.Color.DarkGray;
            this.button118.Enabled = false;
            this.button118.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button118.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button118.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button118.Location = new System.Drawing.Point(547, 372);
            this.button118.Name = "button118";
            this.button118.Size = new System.Drawing.Size(39, 39);
            this.button118.TabIndex = 117;
            this.button118.Text = "8";
            this.button118.UseVisualStyleBackColor = false;
            // 
            // button119
            // 
            this.button119.BackColor = System.Drawing.Color.DarkGray;
            this.button119.Enabled = false;
            this.button119.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button119.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button119.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button119.Location = new System.Drawing.Point(547, 417);
            this.button119.Name = "button119";
            this.button119.Size = new System.Drawing.Size(39, 39);
            this.button119.TabIndex = 118;
            this.button119.Text = "9";
            this.button119.UseVisualStyleBackColor = false;
            // 
            // button120
            // 
            this.button120.BackColor = System.Drawing.Color.White;
            this.button120.Enabled = false;
            this.button120.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button120.Location = new System.Drawing.Point(592, 57);
            this.button120.Name = "button120";
            this.button120.Size = new System.Drawing.Size(39, 39);
            this.button120.TabIndex = 119;
            this.button120.Tag = "";
            this.button120.Text = " ";
            this.button120.UseVisualStyleBackColor = false;
            this.button120.Click += new System.EventHandler(this.button200_Click);
            // 
            // button121
            // 
            this.button121.BackColor = System.Drawing.Color.White;
            this.button121.Enabled = false;
            this.button121.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button121.Location = new System.Drawing.Point(637, 57);
            this.button121.Name = "button121";
            this.button121.Size = new System.Drawing.Size(39, 39);
            this.button121.TabIndex = 120;
            this.button121.Tag = "";
            this.button121.Text = " ";
            this.button121.UseVisualStyleBackColor = false;
            this.button121.Click += new System.EventHandler(this.button200_Click);
            // 
            // button122
            // 
            this.button122.BackColor = System.Drawing.Color.White;
            this.button122.Enabled = false;
            this.button122.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button122.Location = new System.Drawing.Point(682, 57);
            this.button122.Name = "button122";
            this.button122.Size = new System.Drawing.Size(39, 39);
            this.button122.TabIndex = 121;
            this.button122.Tag = "";
            this.button122.Text = " ";
            this.button122.UseVisualStyleBackColor = false;
            this.button122.Click += new System.EventHandler(this.button200_Click);
            // 
            // button123
            // 
            this.button123.BackColor = System.Drawing.Color.White;
            this.button123.Enabled = false;
            this.button123.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button123.Location = new System.Drawing.Point(727, 57);
            this.button123.Name = "button123";
            this.button123.Size = new System.Drawing.Size(39, 39);
            this.button123.TabIndex = 122;
            this.button123.Tag = "";
            this.button123.Text = " ";
            this.button123.UseVisualStyleBackColor = false;
            this.button123.Click += new System.EventHandler(this.button200_Click);
            // 
            // button124
            // 
            this.button124.BackColor = System.Drawing.Color.White;
            this.button124.Enabled = false;
            this.button124.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button124.Location = new System.Drawing.Point(772, 57);
            this.button124.Name = "button124";
            this.button124.Size = new System.Drawing.Size(39, 39);
            this.button124.TabIndex = 123;
            this.button124.Tag = "";
            this.button124.Text = " ";
            this.button124.UseVisualStyleBackColor = false;
            this.button124.Click += new System.EventHandler(this.button200_Click);
            // 
            // button125
            // 
            this.button125.BackColor = System.Drawing.Color.White;
            this.button125.Enabled = false;
            this.button125.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button125.Location = new System.Drawing.Point(817, 57);
            this.button125.Name = "button125";
            this.button125.Size = new System.Drawing.Size(39, 39);
            this.button125.TabIndex = 124;
            this.button125.Tag = "";
            this.button125.Text = " ";
            this.button125.UseVisualStyleBackColor = false;
            this.button125.Click += new System.EventHandler(this.button200_Click);
            // 
            // button126
            // 
            this.button126.BackColor = System.Drawing.Color.White;
            this.button126.Enabled = false;
            this.button126.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button126.Location = new System.Drawing.Point(862, 57);
            this.button126.Name = "button126";
            this.button126.Size = new System.Drawing.Size(39, 39);
            this.button126.TabIndex = 125;
            this.button126.Tag = "";
            this.button126.Text = " ";
            this.button126.UseVisualStyleBackColor = false;
            this.button126.Click += new System.EventHandler(this.button200_Click);
            // 
            // button127
            // 
            this.button127.BackColor = System.Drawing.Color.White;
            this.button127.Enabled = false;
            this.button127.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button127.Location = new System.Drawing.Point(907, 57);
            this.button127.Name = "button127";
            this.button127.Size = new System.Drawing.Size(39, 39);
            this.button127.TabIndex = 126;
            this.button127.Tag = "";
            this.button127.Text = " ";
            this.button127.UseVisualStyleBackColor = false;
            this.button127.Click += new System.EventHandler(this.button200_Click);
            // 
            // button128
            // 
            this.button128.BackColor = System.Drawing.Color.White;
            this.button128.Enabled = false;
            this.button128.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button128.Location = new System.Drawing.Point(952, 57);
            this.button128.Name = "button128";
            this.button128.Size = new System.Drawing.Size(39, 39);
            this.button128.TabIndex = 127;
            this.button128.Tag = "";
            this.button128.Text = " ";
            this.button128.UseVisualStyleBackColor = false;
            this.button128.Click += new System.EventHandler(this.button200_Click);
            // 
            // button129
            // 
            this.button129.BackColor = System.Drawing.Color.White;
            this.button129.Enabled = false;
            this.button129.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button129.Location = new System.Drawing.Point(592, 102);
            this.button129.Name = "button129";
            this.button129.Size = new System.Drawing.Size(39, 39);
            this.button129.TabIndex = 128;
            this.button129.Tag = "";
            this.button129.Text = " ";
            this.button129.UseVisualStyleBackColor = false;
            this.button129.Click += new System.EventHandler(this.button200_Click);
            // 
            // button130
            // 
            this.button130.BackColor = System.Drawing.Color.White;
            this.button130.Enabled = false;
            this.button130.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button130.Location = new System.Drawing.Point(637, 102);
            this.button130.Name = "button130";
            this.button130.Size = new System.Drawing.Size(39, 39);
            this.button130.TabIndex = 129;
            this.button130.Tag = "";
            this.button130.Text = " ";
            this.button130.UseVisualStyleBackColor = false;
            this.button130.Click += new System.EventHandler(this.button200_Click);
            // 
            // button131
            // 
            this.button131.BackColor = System.Drawing.Color.White;
            this.button131.Enabled = false;
            this.button131.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button131.Location = new System.Drawing.Point(682, 102);
            this.button131.Name = "button131";
            this.button131.Size = new System.Drawing.Size(39, 39);
            this.button131.TabIndex = 130;
            this.button131.Tag = "";
            this.button131.Text = " ";
            this.button131.UseVisualStyleBackColor = false;
            this.button131.Click += new System.EventHandler(this.button200_Click);
            // 
            // button132
            // 
            this.button132.BackColor = System.Drawing.Color.White;
            this.button132.Enabled = false;
            this.button132.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button132.Location = new System.Drawing.Point(727, 102);
            this.button132.Name = "button132";
            this.button132.Size = new System.Drawing.Size(39, 39);
            this.button132.TabIndex = 131;
            this.button132.Tag = "";
            this.button132.Text = " ";
            this.button132.UseVisualStyleBackColor = false;
            this.button132.Click += new System.EventHandler(this.button200_Click);
            // 
            // button133
            // 
            this.button133.BackColor = System.Drawing.Color.White;
            this.button133.Enabled = false;
            this.button133.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button133.Location = new System.Drawing.Point(772, 102);
            this.button133.Name = "button133";
            this.button133.Size = new System.Drawing.Size(39, 39);
            this.button133.TabIndex = 132;
            this.button133.Tag = "";
            this.button133.Text = " ";
            this.button133.UseVisualStyleBackColor = false;
            this.button133.Click += new System.EventHandler(this.button200_Click);
            // 
            // button134
            // 
            this.button134.BackColor = System.Drawing.Color.White;
            this.button134.Enabled = false;
            this.button134.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button134.Location = new System.Drawing.Point(817, 102);
            this.button134.Name = "button134";
            this.button134.Size = new System.Drawing.Size(39, 39);
            this.button134.TabIndex = 133;
            this.button134.Tag = "";
            this.button134.Text = " ";
            this.button134.UseVisualStyleBackColor = false;
            this.button134.Click += new System.EventHandler(this.button200_Click);
            // 
            // button135
            // 
            this.button135.BackColor = System.Drawing.Color.White;
            this.button135.Enabled = false;
            this.button135.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button135.Location = new System.Drawing.Point(862, 102);
            this.button135.Name = "button135";
            this.button135.Size = new System.Drawing.Size(39, 39);
            this.button135.TabIndex = 134;
            this.button135.Tag = "";
            this.button135.Text = " ";
            this.button135.UseVisualStyleBackColor = false;
            this.button135.Click += new System.EventHandler(this.button200_Click);
            // 
            // button136
            // 
            this.button136.BackColor = System.Drawing.Color.White;
            this.button136.Enabled = false;
            this.button136.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button136.Location = new System.Drawing.Point(907, 102);
            this.button136.Name = "button136";
            this.button136.Size = new System.Drawing.Size(39, 39);
            this.button136.TabIndex = 135;
            this.button136.Tag = "";
            this.button136.Text = " ";
            this.button136.UseVisualStyleBackColor = false;
            this.button136.Click += new System.EventHandler(this.button200_Click);
            // 
            // button137
            // 
            this.button137.BackColor = System.Drawing.Color.White;
            this.button137.Enabled = false;
            this.button137.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button137.Location = new System.Drawing.Point(952, 102);
            this.button137.Name = "button137";
            this.button137.Size = new System.Drawing.Size(39, 39);
            this.button137.TabIndex = 136;
            this.button137.Tag = "";
            this.button137.Text = " ";
            this.button137.UseVisualStyleBackColor = false;
            this.button137.Click += new System.EventHandler(this.button200_Click);
            // 
            // button138
            // 
            this.button138.BackColor = System.Drawing.Color.White;
            this.button138.Enabled = false;
            this.button138.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button138.Location = new System.Drawing.Point(592, 147);
            this.button138.Name = "button138";
            this.button138.Size = new System.Drawing.Size(39, 39);
            this.button138.TabIndex = 137;
            this.button138.Tag = "";
            this.button138.Text = " ";
            this.button138.UseVisualStyleBackColor = false;
            this.button138.Click += new System.EventHandler(this.button200_Click);
            // 
            // button139
            // 
            this.button139.BackColor = System.Drawing.Color.White;
            this.button139.Enabled = false;
            this.button139.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button139.Location = new System.Drawing.Point(637, 147);
            this.button139.Name = "button139";
            this.button139.Size = new System.Drawing.Size(39, 39);
            this.button139.TabIndex = 138;
            this.button139.Tag = "";
            this.button139.Text = " ";
            this.button139.UseVisualStyleBackColor = false;
            this.button139.Click += new System.EventHandler(this.button200_Click);
            // 
            // button140
            // 
            this.button140.BackColor = System.Drawing.Color.White;
            this.button140.Enabled = false;
            this.button140.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button140.Location = new System.Drawing.Point(682, 147);
            this.button140.Name = "button140";
            this.button140.Size = new System.Drawing.Size(39, 39);
            this.button140.TabIndex = 139;
            this.button140.Tag = "";
            this.button140.Text = " ";
            this.button140.UseVisualStyleBackColor = false;
            this.button140.Click += new System.EventHandler(this.button200_Click);
            // 
            // button141
            // 
            this.button141.BackColor = System.Drawing.Color.White;
            this.button141.Enabled = false;
            this.button141.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button141.Location = new System.Drawing.Point(727, 147);
            this.button141.Name = "button141";
            this.button141.Size = new System.Drawing.Size(39, 39);
            this.button141.TabIndex = 140;
            this.button141.Tag = "";
            this.button141.Text = " ";
            this.button141.UseVisualStyleBackColor = false;
            this.button141.Click += new System.EventHandler(this.button200_Click);
            // 
            // button142
            // 
            this.button142.BackColor = System.Drawing.Color.White;
            this.button142.Enabled = false;
            this.button142.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button142.Location = new System.Drawing.Point(772, 147);
            this.button142.Name = "button142";
            this.button142.Size = new System.Drawing.Size(39, 39);
            this.button142.TabIndex = 141;
            this.button142.Tag = "";
            this.button142.Text = " ";
            this.button142.UseVisualStyleBackColor = false;
            this.button142.Click += new System.EventHandler(this.button200_Click);
            // 
            // button143
            // 
            this.button143.BackColor = System.Drawing.Color.White;
            this.button143.Enabled = false;
            this.button143.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button143.Location = new System.Drawing.Point(817, 147);
            this.button143.Name = "button143";
            this.button143.Size = new System.Drawing.Size(39, 39);
            this.button143.TabIndex = 142;
            this.button143.Tag = "";
            this.button143.Text = " ";
            this.button143.UseVisualStyleBackColor = false;
            this.button143.Click += new System.EventHandler(this.button200_Click);
            // 
            // button144
            // 
            this.button144.BackColor = System.Drawing.Color.White;
            this.button144.Enabled = false;
            this.button144.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button144.Location = new System.Drawing.Point(862, 147);
            this.button144.Name = "button144";
            this.button144.Size = new System.Drawing.Size(39, 39);
            this.button144.TabIndex = 143;
            this.button144.Tag = "";
            this.button144.Text = " ";
            this.button144.UseVisualStyleBackColor = false;
            this.button144.Click += new System.EventHandler(this.button200_Click);
            // 
            // button145
            // 
            this.button145.BackColor = System.Drawing.Color.White;
            this.button145.Enabled = false;
            this.button145.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button145.Location = new System.Drawing.Point(907, 147);
            this.button145.Name = "button145";
            this.button145.Size = new System.Drawing.Size(39, 39);
            this.button145.TabIndex = 144;
            this.button145.Tag = "";
            this.button145.Text = " ";
            this.button145.UseVisualStyleBackColor = false;
            this.button145.Click += new System.EventHandler(this.button200_Click);
            // 
            // button146
            // 
            this.button146.BackColor = System.Drawing.Color.White;
            this.button146.Enabled = false;
            this.button146.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button146.Location = new System.Drawing.Point(952, 147);
            this.button146.Name = "button146";
            this.button146.Size = new System.Drawing.Size(39, 39);
            this.button146.TabIndex = 145;
            this.button146.Tag = "";
            this.button146.Text = " ";
            this.button146.UseVisualStyleBackColor = false;
            this.button146.Click += new System.EventHandler(this.button200_Click);
            // 
            // button147
            // 
            this.button147.BackColor = System.Drawing.Color.White;
            this.button147.Enabled = false;
            this.button147.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button147.Location = new System.Drawing.Point(592, 192);
            this.button147.Name = "button147";
            this.button147.Size = new System.Drawing.Size(39, 39);
            this.button147.TabIndex = 146;
            this.button147.Tag = "";
            this.button147.Text = " ";
            this.button147.UseVisualStyleBackColor = false;
            this.button147.Click += new System.EventHandler(this.button200_Click);
            // 
            // button148
            // 
            this.button148.BackColor = System.Drawing.Color.White;
            this.button148.Enabled = false;
            this.button148.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button148.Location = new System.Drawing.Point(637, 192);
            this.button148.Name = "button148";
            this.button148.Size = new System.Drawing.Size(39, 39);
            this.button148.TabIndex = 147;
            this.button148.Tag = "";
            this.button148.Text = " ";
            this.button148.UseVisualStyleBackColor = false;
            this.button148.Click += new System.EventHandler(this.button200_Click);
            // 
            // button149
            // 
            this.button149.BackColor = System.Drawing.Color.White;
            this.button149.Enabled = false;
            this.button149.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button149.Location = new System.Drawing.Point(682, 192);
            this.button149.Name = "button149";
            this.button149.Size = new System.Drawing.Size(39, 39);
            this.button149.TabIndex = 148;
            this.button149.Tag = "";
            this.button149.Text = " ";
            this.button149.UseVisualStyleBackColor = false;
            this.button149.Click += new System.EventHandler(this.button200_Click);
            // 
            // button150
            // 
            this.button150.BackColor = System.Drawing.Color.White;
            this.button150.Enabled = false;
            this.button150.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button150.Location = new System.Drawing.Point(727, 192);
            this.button150.Name = "button150";
            this.button150.Size = new System.Drawing.Size(39, 39);
            this.button150.TabIndex = 149;
            this.button150.Tag = "";
            this.button150.Text = " ";
            this.button150.UseVisualStyleBackColor = false;
            this.button150.Click += new System.EventHandler(this.button200_Click);
            // 
            // button151
            // 
            this.button151.BackColor = System.Drawing.Color.White;
            this.button151.Enabled = false;
            this.button151.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button151.Location = new System.Drawing.Point(772, 192);
            this.button151.Name = "button151";
            this.button151.Size = new System.Drawing.Size(39, 39);
            this.button151.TabIndex = 150;
            this.button151.Tag = "";
            this.button151.Text = " ";
            this.button151.UseVisualStyleBackColor = false;
            this.button151.Click += new System.EventHandler(this.button200_Click);
            // 
            // button152
            // 
            this.button152.BackColor = System.Drawing.Color.White;
            this.button152.Enabled = false;
            this.button152.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button152.Location = new System.Drawing.Point(817, 192);
            this.button152.Name = "button152";
            this.button152.Size = new System.Drawing.Size(39, 39);
            this.button152.TabIndex = 151;
            this.button152.Tag = "";
            this.button152.Text = " ";
            this.button152.UseVisualStyleBackColor = false;
            this.button152.Click += new System.EventHandler(this.button200_Click);
            // 
            // button153
            // 
            this.button153.BackColor = System.Drawing.Color.White;
            this.button153.Enabled = false;
            this.button153.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button153.Location = new System.Drawing.Point(862, 192);
            this.button153.Name = "button153";
            this.button153.Size = new System.Drawing.Size(39, 39);
            this.button153.TabIndex = 152;
            this.button153.Tag = "";
            this.button153.Text = " ";
            this.button153.UseVisualStyleBackColor = false;
            this.button153.Click += new System.EventHandler(this.button200_Click);
            // 
            // button154
            // 
            this.button154.BackColor = System.Drawing.Color.White;
            this.button154.Enabled = false;
            this.button154.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button154.Location = new System.Drawing.Point(907, 192);
            this.button154.Name = "button154";
            this.button154.Size = new System.Drawing.Size(39, 39);
            this.button154.TabIndex = 153;
            this.button154.Tag = "";
            this.button154.Text = " ";
            this.button154.UseVisualStyleBackColor = false;
            this.button154.Click += new System.EventHandler(this.button200_Click);
            // 
            // button155
            // 
            this.button155.BackColor = System.Drawing.Color.White;
            this.button155.Enabled = false;
            this.button155.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button155.Location = new System.Drawing.Point(952, 192);
            this.button155.Name = "button155";
            this.button155.Size = new System.Drawing.Size(39, 39);
            this.button155.TabIndex = 154;
            this.button155.Tag = "";
            this.button155.Text = " ";
            this.button155.UseVisualStyleBackColor = false;
            this.button155.Click += new System.EventHandler(this.button200_Click);
            // 
            // button156
            // 
            this.button156.BackColor = System.Drawing.Color.White;
            this.button156.Enabled = false;
            this.button156.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button156.Location = new System.Drawing.Point(592, 237);
            this.button156.Name = "button156";
            this.button156.Size = new System.Drawing.Size(39, 39);
            this.button156.TabIndex = 155;
            this.button156.Tag = "";
            this.button156.Text = " ";
            this.button156.UseVisualStyleBackColor = false;
            this.button156.Click += new System.EventHandler(this.button200_Click);
            // 
            // button157
            // 
            this.button157.BackColor = System.Drawing.Color.White;
            this.button157.Enabled = false;
            this.button157.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button157.Location = new System.Drawing.Point(637, 237);
            this.button157.Name = "button157";
            this.button157.Size = new System.Drawing.Size(39, 39);
            this.button157.TabIndex = 156;
            this.button157.Tag = "";
            this.button157.Text = " ";
            this.button157.UseVisualStyleBackColor = false;
            this.button157.Click += new System.EventHandler(this.button200_Click);
            // 
            // button158
            // 
            this.button158.BackColor = System.Drawing.Color.White;
            this.button158.Enabled = false;
            this.button158.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button158.Location = new System.Drawing.Point(682, 237);
            this.button158.Name = "button158";
            this.button158.Size = new System.Drawing.Size(39, 39);
            this.button158.TabIndex = 157;
            this.button158.Tag = "";
            this.button158.Text = " ";
            this.button158.UseVisualStyleBackColor = false;
            this.button158.Click += new System.EventHandler(this.button200_Click);
            // 
            // button159
            // 
            this.button159.BackColor = System.Drawing.Color.White;
            this.button159.Enabled = false;
            this.button159.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button159.Location = new System.Drawing.Point(727, 237);
            this.button159.Name = "button159";
            this.button159.Size = new System.Drawing.Size(39, 39);
            this.button159.TabIndex = 158;
            this.button159.Tag = "";
            this.button159.Text = " ";
            this.button159.UseVisualStyleBackColor = false;
            this.button159.Click += new System.EventHandler(this.button200_Click);
            // 
            // button160
            // 
            this.button160.BackColor = System.Drawing.Color.White;
            this.button160.Enabled = false;
            this.button160.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button160.Location = new System.Drawing.Point(772, 237);
            this.button160.Name = "button160";
            this.button160.Size = new System.Drawing.Size(39, 39);
            this.button160.TabIndex = 159;
            this.button160.Tag = "";
            this.button160.Text = " ";
            this.button160.UseVisualStyleBackColor = false;
            this.button160.Click += new System.EventHandler(this.button200_Click);
            // 
            // button161
            // 
            this.button161.BackColor = System.Drawing.Color.White;
            this.button161.Enabled = false;
            this.button161.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button161.Location = new System.Drawing.Point(817, 237);
            this.button161.Name = "button161";
            this.button161.Size = new System.Drawing.Size(39, 39);
            this.button161.TabIndex = 160;
            this.button161.Tag = "";
            this.button161.Text = " ";
            this.button161.UseVisualStyleBackColor = false;
            this.button161.Click += new System.EventHandler(this.button200_Click);
            // 
            // button162
            // 
            this.button162.BackColor = System.Drawing.Color.White;
            this.button162.Enabled = false;
            this.button162.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button162.Location = new System.Drawing.Point(862, 237);
            this.button162.Name = "button162";
            this.button162.Size = new System.Drawing.Size(39, 39);
            this.button162.TabIndex = 161;
            this.button162.Tag = "";
            this.button162.Text = " ";
            this.button162.UseVisualStyleBackColor = false;
            this.button162.Click += new System.EventHandler(this.button200_Click);
            // 
            // button163
            // 
            this.button163.BackColor = System.Drawing.Color.White;
            this.button163.Enabled = false;
            this.button163.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button163.Location = new System.Drawing.Point(907, 237);
            this.button163.Name = "button163";
            this.button163.Size = new System.Drawing.Size(39, 39);
            this.button163.TabIndex = 162;
            this.button163.Tag = "";
            this.button163.Text = " ";
            this.button163.UseVisualStyleBackColor = false;
            this.button163.Click += new System.EventHandler(this.button200_Click);
            // 
            // button164
            // 
            this.button164.BackColor = System.Drawing.Color.White;
            this.button164.Enabled = false;
            this.button164.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button164.Location = new System.Drawing.Point(952, 237);
            this.button164.Name = "button164";
            this.button164.Size = new System.Drawing.Size(39, 39);
            this.button164.TabIndex = 163;
            this.button164.Tag = "";
            this.button164.Text = " ";
            this.button164.UseVisualStyleBackColor = false;
            this.button164.Click += new System.EventHandler(this.button200_Click);
            // 
            // button165
            // 
            this.button165.BackColor = System.Drawing.Color.White;
            this.button165.Enabled = false;
            this.button165.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button165.Location = new System.Drawing.Point(592, 282);
            this.button165.Name = "button165";
            this.button165.Size = new System.Drawing.Size(39, 39);
            this.button165.TabIndex = 164;
            this.button165.Tag = "";
            this.button165.Text = " ";
            this.button165.UseVisualStyleBackColor = false;
            this.button165.Click += new System.EventHandler(this.button200_Click);
            // 
            // button166
            // 
            this.button166.BackColor = System.Drawing.Color.White;
            this.button166.Enabled = false;
            this.button166.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button166.Location = new System.Drawing.Point(637, 282);
            this.button166.Name = "button166";
            this.button166.Size = new System.Drawing.Size(39, 39);
            this.button166.TabIndex = 165;
            this.button166.Tag = "";
            this.button166.Text = " ";
            this.button166.UseVisualStyleBackColor = false;
            this.button166.Click += new System.EventHandler(this.button200_Click);
            // 
            // button167
            // 
            this.button167.BackColor = System.Drawing.Color.White;
            this.button167.Enabled = false;
            this.button167.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button167.Location = new System.Drawing.Point(682, 282);
            this.button167.Name = "button167";
            this.button167.Size = new System.Drawing.Size(39, 39);
            this.button167.TabIndex = 166;
            this.button167.Tag = "";
            this.button167.Text = " ";
            this.button167.UseVisualStyleBackColor = false;
            this.button167.Click += new System.EventHandler(this.button200_Click);
            // 
            // button168
            // 
            this.button168.BackColor = System.Drawing.Color.White;
            this.button168.Enabled = false;
            this.button168.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button168.Location = new System.Drawing.Point(727, 282);
            this.button168.Name = "button168";
            this.button168.Size = new System.Drawing.Size(39, 39);
            this.button168.TabIndex = 167;
            this.button168.Tag = "";
            this.button168.Text = " ";
            this.button168.UseVisualStyleBackColor = false;
            this.button168.Click += new System.EventHandler(this.button200_Click);
            // 
            // button169
            // 
            this.button169.BackColor = System.Drawing.Color.White;
            this.button169.Enabled = false;
            this.button169.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button169.Location = new System.Drawing.Point(772, 282);
            this.button169.Name = "button169";
            this.button169.Size = new System.Drawing.Size(39, 39);
            this.button169.TabIndex = 168;
            this.button169.Tag = "";
            this.button169.Text = " ";
            this.button169.UseVisualStyleBackColor = false;
            this.button169.Click += new System.EventHandler(this.button200_Click);
            // 
            // button170
            // 
            this.button170.BackColor = System.Drawing.Color.White;
            this.button170.Enabled = false;
            this.button170.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button170.Location = new System.Drawing.Point(817, 282);
            this.button170.Name = "button170";
            this.button170.Size = new System.Drawing.Size(39, 39);
            this.button170.TabIndex = 169;
            this.button170.Tag = "";
            this.button170.Text = " ";
            this.button170.UseVisualStyleBackColor = false;
            this.button170.Click += new System.EventHandler(this.button200_Click);
            // 
            // button171
            // 
            this.button171.BackColor = System.Drawing.Color.White;
            this.button171.Enabled = false;
            this.button171.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button171.Location = new System.Drawing.Point(862, 282);
            this.button171.Name = "button171";
            this.button171.Size = new System.Drawing.Size(39, 39);
            this.button171.TabIndex = 170;
            this.button171.Tag = "";
            this.button171.Text = " ";
            this.button171.UseVisualStyleBackColor = false;
            this.button171.Click += new System.EventHandler(this.button200_Click);
            // 
            // button172
            // 
            this.button172.BackColor = System.Drawing.Color.White;
            this.button172.Enabled = false;
            this.button172.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button172.Location = new System.Drawing.Point(907, 282);
            this.button172.Name = "button172";
            this.button172.Size = new System.Drawing.Size(39, 39);
            this.button172.TabIndex = 171;
            this.button172.Tag = "";
            this.button172.Text = " ";
            this.button172.UseVisualStyleBackColor = false;
            this.button172.Click += new System.EventHandler(this.button200_Click);
            // 
            // button173
            // 
            this.button173.BackColor = System.Drawing.Color.White;
            this.button173.Enabled = false;
            this.button173.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button173.Location = new System.Drawing.Point(952, 282);
            this.button173.Name = "button173";
            this.button173.Size = new System.Drawing.Size(39, 39);
            this.button173.TabIndex = 172;
            this.button173.Tag = "";
            this.button173.Text = " ";
            this.button173.UseVisualStyleBackColor = false;
            this.button173.Click += new System.EventHandler(this.button200_Click);
            // 
            // button174
            // 
            this.button174.BackColor = System.Drawing.Color.White;
            this.button174.Enabled = false;
            this.button174.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button174.Location = new System.Drawing.Point(592, 327);
            this.button174.Name = "button174";
            this.button174.Size = new System.Drawing.Size(39, 39);
            this.button174.TabIndex = 173;
            this.button174.Tag = "";
            this.button174.Text = " ";
            this.button174.UseVisualStyleBackColor = false;
            this.button174.Click += new System.EventHandler(this.button200_Click);
            // 
            // button175
            // 
            this.button175.BackColor = System.Drawing.Color.White;
            this.button175.Enabled = false;
            this.button175.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button175.Location = new System.Drawing.Point(637, 327);
            this.button175.Name = "button175";
            this.button175.Size = new System.Drawing.Size(39, 39);
            this.button175.TabIndex = 174;
            this.button175.Tag = "";
            this.button175.Text = " ";
            this.button175.UseVisualStyleBackColor = false;
            this.button175.Click += new System.EventHandler(this.button200_Click);
            // 
            // button176
            // 
            this.button176.BackColor = System.Drawing.Color.White;
            this.button176.Enabled = false;
            this.button176.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button176.Location = new System.Drawing.Point(682, 327);
            this.button176.Name = "button176";
            this.button176.Size = new System.Drawing.Size(39, 39);
            this.button176.TabIndex = 175;
            this.button176.Tag = "";
            this.button176.Text = " ";
            this.button176.UseVisualStyleBackColor = false;
            this.button176.Click += new System.EventHandler(this.button200_Click);
            // 
            // button177
            // 
            this.button177.BackColor = System.Drawing.Color.White;
            this.button177.Enabled = false;
            this.button177.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button177.Location = new System.Drawing.Point(727, 327);
            this.button177.Name = "button177";
            this.button177.Size = new System.Drawing.Size(39, 39);
            this.button177.TabIndex = 176;
            this.button177.Tag = "";
            this.button177.Text = " ";
            this.button177.UseVisualStyleBackColor = false;
            this.button177.Click += new System.EventHandler(this.button200_Click);
            // 
            // button178
            // 
            this.button178.BackColor = System.Drawing.Color.White;
            this.button178.Enabled = false;
            this.button178.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button178.Location = new System.Drawing.Point(772, 327);
            this.button178.Name = "button178";
            this.button178.Size = new System.Drawing.Size(39, 39);
            this.button178.TabIndex = 177;
            this.button178.Tag = "";
            this.button178.Text = " ";
            this.button178.UseVisualStyleBackColor = false;
            this.button178.Click += new System.EventHandler(this.button200_Click);
            // 
            // button179
            // 
            this.button179.BackColor = System.Drawing.Color.White;
            this.button179.Enabled = false;
            this.button179.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button179.Location = new System.Drawing.Point(817, 327);
            this.button179.Name = "button179";
            this.button179.Size = new System.Drawing.Size(39, 39);
            this.button179.TabIndex = 178;
            this.button179.Tag = "";
            this.button179.Text = " ";
            this.button179.UseVisualStyleBackColor = false;
            this.button179.Click += new System.EventHandler(this.button200_Click);
            // 
            // button180
            // 
            this.button180.BackColor = System.Drawing.Color.White;
            this.button180.Enabled = false;
            this.button180.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button180.Location = new System.Drawing.Point(862, 327);
            this.button180.Name = "button180";
            this.button180.Size = new System.Drawing.Size(39, 39);
            this.button180.TabIndex = 179;
            this.button180.Tag = "";
            this.button180.Text = " ";
            this.button180.UseVisualStyleBackColor = false;
            this.button180.Click += new System.EventHandler(this.button200_Click);
            // 
            // button181
            // 
            this.button181.BackColor = System.Drawing.Color.White;
            this.button181.Enabled = false;
            this.button181.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button181.Location = new System.Drawing.Point(907, 327);
            this.button181.Name = "button181";
            this.button181.Size = new System.Drawing.Size(39, 39);
            this.button181.TabIndex = 180;
            this.button181.Tag = "";
            this.button181.Text = " ";
            this.button181.UseVisualStyleBackColor = false;
            this.button181.Click += new System.EventHandler(this.button200_Click);
            // 
            // button182
            // 
            this.button182.BackColor = System.Drawing.Color.White;
            this.button182.Enabled = false;
            this.button182.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button182.Location = new System.Drawing.Point(952, 327);
            this.button182.Name = "button182";
            this.button182.Size = new System.Drawing.Size(39, 39);
            this.button182.TabIndex = 181;
            this.button182.Tag = "";
            this.button182.Text = " ";
            this.button182.UseVisualStyleBackColor = false;
            this.button182.Click += new System.EventHandler(this.button200_Click);
            // 
            // button183
            // 
            this.button183.BackColor = System.Drawing.Color.White;
            this.button183.Enabled = false;
            this.button183.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button183.Location = new System.Drawing.Point(592, 372);
            this.button183.Name = "button183";
            this.button183.Size = new System.Drawing.Size(39, 39);
            this.button183.TabIndex = 182;
            this.button183.Tag = "";
            this.button183.Text = " ";
            this.button183.UseVisualStyleBackColor = false;
            this.button183.Click += new System.EventHandler(this.button200_Click);
            // 
            // button184
            // 
            this.button184.BackColor = System.Drawing.Color.White;
            this.button184.Enabled = false;
            this.button184.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button184.Location = new System.Drawing.Point(637, 372);
            this.button184.Name = "button184";
            this.button184.Size = new System.Drawing.Size(39, 39);
            this.button184.TabIndex = 183;
            this.button184.Tag = "";
            this.button184.Text = " ";
            this.button184.UseVisualStyleBackColor = false;
            this.button184.Click += new System.EventHandler(this.button200_Click);
            // 
            // button185
            // 
            this.button185.BackColor = System.Drawing.Color.White;
            this.button185.Enabled = false;
            this.button185.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button185.Location = new System.Drawing.Point(682, 372);
            this.button185.Name = "button185";
            this.button185.Size = new System.Drawing.Size(39, 39);
            this.button185.TabIndex = 184;
            this.button185.Tag = "";
            this.button185.Text = " ";
            this.button185.UseVisualStyleBackColor = false;
            this.button185.Click += new System.EventHandler(this.button200_Click);
            // 
            // button186
            // 
            this.button186.BackColor = System.Drawing.Color.White;
            this.button186.Enabled = false;
            this.button186.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button186.Location = new System.Drawing.Point(727, 372);
            this.button186.Name = "button186";
            this.button186.Size = new System.Drawing.Size(39, 39);
            this.button186.TabIndex = 185;
            this.button186.Tag = "";
            this.button186.Text = " ";
            this.button186.UseVisualStyleBackColor = false;
            this.button186.Click += new System.EventHandler(this.button200_Click);
            // 
            // button187
            // 
            this.button187.BackColor = System.Drawing.Color.White;
            this.button187.Enabled = false;
            this.button187.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button187.Location = new System.Drawing.Point(772, 372);
            this.button187.Name = "button187";
            this.button187.Size = new System.Drawing.Size(39, 39);
            this.button187.TabIndex = 186;
            this.button187.Tag = "";
            this.button187.Text = " ";
            this.button187.UseVisualStyleBackColor = false;
            this.button187.Click += new System.EventHandler(this.button200_Click);
            // 
            // button188
            // 
            this.button188.BackColor = System.Drawing.Color.White;
            this.button188.Enabled = false;
            this.button188.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button188.Location = new System.Drawing.Point(817, 372);
            this.button188.Name = "button188";
            this.button188.Size = new System.Drawing.Size(39, 39);
            this.button188.TabIndex = 187;
            this.button188.Tag = "";
            this.button188.Text = " ";
            this.button188.UseVisualStyleBackColor = false;
            this.button188.Click += new System.EventHandler(this.button200_Click);
            // 
            // button189
            // 
            this.button189.BackColor = System.Drawing.Color.White;
            this.button189.Enabled = false;
            this.button189.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button189.Location = new System.Drawing.Point(862, 372);
            this.button189.Name = "button189";
            this.button189.Size = new System.Drawing.Size(39, 39);
            this.button189.TabIndex = 188;
            this.button189.Tag = "";
            this.button189.Text = " ";
            this.button189.UseVisualStyleBackColor = false;
            this.button189.Click += new System.EventHandler(this.button200_Click);
            // 
            // button190
            // 
            this.button190.BackColor = System.Drawing.Color.White;
            this.button190.Enabled = false;
            this.button190.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button190.Location = new System.Drawing.Point(907, 372);
            this.button190.Name = "button190";
            this.button190.Size = new System.Drawing.Size(39, 39);
            this.button190.TabIndex = 189;
            this.button190.Tag = "";
            this.button190.Text = " ";
            this.button190.UseVisualStyleBackColor = false;
            this.button190.Click += new System.EventHandler(this.button200_Click);
            // 
            // button191
            // 
            this.button191.BackColor = System.Drawing.Color.White;
            this.button191.Enabled = false;
            this.button191.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button191.Location = new System.Drawing.Point(952, 372);
            this.button191.Name = "button191";
            this.button191.Size = new System.Drawing.Size(39, 39);
            this.button191.TabIndex = 190;
            this.button191.Tag = "";
            this.button191.Text = " ";
            this.button191.UseVisualStyleBackColor = false;
            this.button191.Click += new System.EventHandler(this.button200_Click);
            // 
            // button192
            // 
            this.button192.BackColor = System.Drawing.Color.White;
            this.button192.Enabled = false;
            this.button192.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button192.Location = new System.Drawing.Point(592, 417);
            this.button192.Name = "button192";
            this.button192.Size = new System.Drawing.Size(39, 39);
            this.button192.TabIndex = 191;
            this.button192.Tag = "";
            this.button192.Text = " ";
            this.button192.UseVisualStyleBackColor = false;
            this.button192.Click += new System.EventHandler(this.button200_Click);
            // 
            // button193
            // 
            this.button193.BackColor = System.Drawing.Color.White;
            this.button193.Enabled = false;
            this.button193.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button193.Location = new System.Drawing.Point(637, 417);
            this.button193.Name = "button193";
            this.button193.Size = new System.Drawing.Size(39, 39);
            this.button193.TabIndex = 192;
            this.button193.Tag = "";
            this.button193.Text = " ";
            this.button193.UseVisualStyleBackColor = false;
            this.button193.Click += new System.EventHandler(this.button200_Click);
            // 
            // button194
            // 
            this.button194.BackColor = System.Drawing.Color.White;
            this.button194.Enabled = false;
            this.button194.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button194.Location = new System.Drawing.Point(682, 417);
            this.button194.Name = "button194";
            this.button194.Size = new System.Drawing.Size(39, 39);
            this.button194.TabIndex = 193;
            this.button194.Tag = "";
            this.button194.Text = " ";
            this.button194.UseVisualStyleBackColor = false;
            this.button194.Click += new System.EventHandler(this.button200_Click);
            // 
            // button195
            // 
            this.button195.BackColor = System.Drawing.Color.White;
            this.button195.Enabled = false;
            this.button195.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button195.Location = new System.Drawing.Point(727, 417);
            this.button195.Name = "button195";
            this.button195.Size = new System.Drawing.Size(39, 39);
            this.button195.TabIndex = 194;
            this.button195.Tag = "";
            this.button195.Text = " ";
            this.button195.UseVisualStyleBackColor = false;
            this.button195.Click += new System.EventHandler(this.button200_Click);
            // 
            // button196
            // 
            this.button196.BackColor = System.Drawing.Color.White;
            this.button196.Enabled = false;
            this.button196.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button196.Location = new System.Drawing.Point(772, 417);
            this.button196.Name = "button196";
            this.button196.Size = new System.Drawing.Size(39, 39);
            this.button196.TabIndex = 195;
            this.button196.Tag = "";
            this.button196.Text = " ";
            this.button196.UseVisualStyleBackColor = false;
            this.button196.Click += new System.EventHandler(this.button200_Click);
            // 
            // button197
            // 
            this.button197.BackColor = System.Drawing.Color.White;
            this.button197.Enabled = false;
            this.button197.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button197.Location = new System.Drawing.Point(817, 417);
            this.button197.Name = "button197";
            this.button197.Size = new System.Drawing.Size(39, 39);
            this.button197.TabIndex = 196;
            this.button197.Tag = "";
            this.button197.Text = " ";
            this.button197.UseVisualStyleBackColor = false;
            this.button197.Click += new System.EventHandler(this.button200_Click);
            // 
            // button198
            // 
            this.button198.BackColor = System.Drawing.Color.White;
            this.button198.Enabled = false;
            this.button198.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button198.Location = new System.Drawing.Point(862, 417);
            this.button198.Name = "button198";
            this.button198.Size = new System.Drawing.Size(39, 39);
            this.button198.TabIndex = 197;
            this.button198.Tag = "";
            this.button198.Text = " ";
            this.button198.UseVisualStyleBackColor = false;
            this.button198.Click += new System.EventHandler(this.button200_Click);
            // 
            // button199
            // 
            this.button199.BackColor = System.Drawing.Color.White;
            this.button199.Enabled = false;
            this.button199.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button199.Location = new System.Drawing.Point(907, 417);
            this.button199.Name = "button199";
            this.button199.Size = new System.Drawing.Size(39, 39);
            this.button199.TabIndex = 198;
            this.button199.Tag = "";
            this.button199.Text = " ";
            this.button199.UseVisualStyleBackColor = false;
            this.button199.Click += new System.EventHandler(this.button200_Click);
            // 
            // button200
            // 
            this.button200.BackColor = System.Drawing.Color.White;
            this.button200.Enabled = false;
            this.button200.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button200.Location = new System.Drawing.Point(952, 417);
            this.button200.Name = "button200";
            this.button200.Size = new System.Drawing.Size(39, 39);
            this.button200.TabIndex = 199;
            this.button200.Tag = "";
            this.button200.Text = " ";
            this.button200.UseVisualStyleBackColor = false;
            this.button200.Click += new System.EventHandler(this.button200_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Enabled = false;
            this.richTextBox1.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.richTextBox1.ForeColor = System.Drawing.Color.DarkBlue;
            this.richTextBox1.Location = new System.Drawing.Point(268, 519);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(480, 34);
            this.richTextBox1.TabIndex = 203;
            this.richTextBox1.Text = "";
            // 
            // ReadRulls
            // 
            this.ReadRulls.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ReadRulls.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ReadRulls.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ReadRulls.Location = new System.Drawing.Point(358, 583);
            this.ReadRulls.Name = "ReadRulls";
            this.ReadRulls.Size = new System.Drawing.Size(98, 54);
            this.ReadRulls.TabIndex = 206;
            this.ReadRulls.Text = "Правила игры";
            this.ReadRulls.UseVisualStyleBackColor = false;
            this.ReadRulls.Click += new System.EventHandler(this.ReadRulls_Click);
            // 
            // button201
            // 
            this.button201.BackColor = System.Drawing.SystemColors.ControlLight;
            this.button201.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button201.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button201.Location = new System.Drawing.Point(547, 583);
            this.button201.Name = "button201";
            this.button201.Size = new System.Drawing.Size(98, 54);
            this.button201.TabIndex = 207;
            this.button201.Text = "Перезапустить";
            this.button201.UseVisualStyleBackColor = false;
            this.button201.Click += new System.EventHandler(this.button201_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSkyBlue;
            this.BackgroundImage = global::SeaFight.Properties.Resources.Море51;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1006, 653);
            this.Controls.Add(this.button201);
            this.Controls.Add(this.ReadRulls);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.button200);
            this.Controls.Add(this.button199);
            this.Controls.Add(this.button198);
            this.Controls.Add(this.button197);
            this.Controls.Add(this.button196);
            this.Controls.Add(this.button195);
            this.Controls.Add(this.button194);
            this.Controls.Add(this.button193);
            this.Controls.Add(this.button192);
            this.Controls.Add(this.button191);
            this.Controls.Add(this.button190);
            this.Controls.Add(this.button189);
            this.Controls.Add(this.button188);
            this.Controls.Add(this.button187);
            this.Controls.Add(this.button186);
            this.Controls.Add(this.button185);
            this.Controls.Add(this.button184);
            this.Controls.Add(this.button183);
            this.Controls.Add(this.button182);
            this.Controls.Add(this.button181);
            this.Controls.Add(this.button180);
            this.Controls.Add(this.button179);
            this.Controls.Add(this.button178);
            this.Controls.Add(this.button177);
            this.Controls.Add(this.button176);
            this.Controls.Add(this.button175);
            this.Controls.Add(this.button174);
            this.Controls.Add(this.button173);
            this.Controls.Add(this.button172);
            this.Controls.Add(this.button171);
            this.Controls.Add(this.button170);
            this.Controls.Add(this.button169);
            this.Controls.Add(this.button168);
            this.Controls.Add(this.button167);
            this.Controls.Add(this.button166);
            this.Controls.Add(this.button165);
            this.Controls.Add(this.button164);
            this.Controls.Add(this.button163);
            this.Controls.Add(this.button162);
            this.Controls.Add(this.button161);
            this.Controls.Add(this.button160);
            this.Controls.Add(this.button159);
            this.Controls.Add(this.button158);
            this.Controls.Add(this.button157);
            this.Controls.Add(this.button156);
            this.Controls.Add(this.button155);
            this.Controls.Add(this.button154);
            this.Controls.Add(this.button153);
            this.Controls.Add(this.button152);
            this.Controls.Add(this.button151);
            this.Controls.Add(this.button150);
            this.Controls.Add(this.button149);
            this.Controls.Add(this.button148);
            this.Controls.Add(this.button147);
            this.Controls.Add(this.button146);
            this.Controls.Add(this.button145);
            this.Controls.Add(this.button144);
            this.Controls.Add(this.button143);
            this.Controls.Add(this.button142);
            this.Controls.Add(this.button141);
            this.Controls.Add(this.button140);
            this.Controls.Add(this.button139);
            this.Controls.Add(this.button138);
            this.Controls.Add(this.button137);
            this.Controls.Add(this.button136);
            this.Controls.Add(this.button135);
            this.Controls.Add(this.button134);
            this.Controls.Add(this.button133);
            this.Controls.Add(this.button132);
            this.Controls.Add(this.button131);
            this.Controls.Add(this.button130);
            this.Controls.Add(this.button129);
            this.Controls.Add(this.button128);
            this.Controls.Add(this.button127);
            this.Controls.Add(this.button126);
            this.Controls.Add(this.button125);
            this.Controls.Add(this.button124);
            this.Controls.Add(this.button123);
            this.Controls.Add(this.button122);
            this.Controls.Add(this.button121);
            this.Controls.Add(this.button120);
            this.Controls.Add(this.button119);
            this.Controls.Add(this.button118);
            this.Controls.Add(this.button117);
            this.Controls.Add(this.button116);
            this.Controls.Add(this.button115);
            this.Controls.Add(this.button114);
            this.Controls.Add(this.button113);
            this.Controls.Add(this.button112);
            this.Controls.Add(this.button111);
            this.Controls.Add(this.button110);
            this.Controls.Add(this.button109);
            this.Controls.Add(this.button108);
            this.Controls.Add(this.button107);
            this.Controls.Add(this.button106);
            this.Controls.Add(this.button105);
            this.Controls.Add(this.button104);
            this.Controls.Add(this.button103);
            this.Controls.Add(this.button102);
            this.Controls.Add(this.button101);
            this.Controls.Add(this.button100);
            this.Controls.Add(this.button99);
            this.Controls.Add(this.button98);
            this.Controls.Add(this.button97);
            this.Controls.Add(this.button96);
            this.Controls.Add(this.button95);
            this.Controls.Add(this.button94);
            this.Controls.Add(this.button93);
            this.Controls.Add(this.button92);
            this.Controls.Add(this.button91);
            this.Controls.Add(this.button90);
            this.Controls.Add(this.button89);
            this.Controls.Add(this.button88);
            this.Controls.Add(this.button87);
            this.Controls.Add(this.button86);
            this.Controls.Add(this.button85);
            this.Controls.Add(this.button84);
            this.Controls.Add(this.button83);
            this.Controls.Add(this.button82);
            this.Controls.Add(this.button81);
            this.Controls.Add(this.button80);
            this.Controls.Add(this.button79);
            this.Controls.Add(this.button78);
            this.Controls.Add(this.button77);
            this.Controls.Add(this.button76);
            this.Controls.Add(this.button75);
            this.Controls.Add(this.button74);
            this.Controls.Add(this.button73);
            this.Controls.Add(this.button72);
            this.Controls.Add(this.button71);
            this.Controls.Add(this.button70);
            this.Controls.Add(this.button69);
            this.Controls.Add(this.button68);
            this.Controls.Add(this.button67);
            this.Controls.Add(this.button66);
            this.Controls.Add(this.button65);
            this.Controls.Add(this.button64);
            this.Controls.Add(this.button63);
            this.Controls.Add(this.button62);
            this.Controls.Add(this.button61);
            this.Controls.Add(this.button60);
            this.Controls.Add(this.button59);
            this.Controls.Add(this.button58);
            this.Controls.Add(this.button57);
            this.Controls.Add(this.button56);
            this.Controls.Add(this.button55);
            this.Controls.Add(this.button54);
            this.Controls.Add(this.button53);
            this.Controls.Add(this.button52);
            this.Controls.Add(this.button51);
            this.Controls.Add(this.button50);
            this.Controls.Add(this.button49);
            this.Controls.Add(this.button48);
            this.Controls.Add(this.button47);
            this.Controls.Add(this.button46);
            this.Controls.Add(this.button45);
            this.Controls.Add(this.button44);
            this.Controls.Add(this.button43);
            this.Controls.Add(this.button42);
            this.Controls.Add(this.button41);
            this.Controls.Add(this.button40);
            this.Controls.Add(this.button39);
            this.Controls.Add(this.button38);
            this.Controls.Add(this.button37);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.button34);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Морской бой";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.Button button88;
        private System.Windows.Forms.Button button89;
        private System.Windows.Forms.Button button90;
        private System.Windows.Forms.Button button91;
        private System.Windows.Forms.Button button92;
        private System.Windows.Forms.Button button93;
        private System.Windows.Forms.Button button94;
        private System.Windows.Forms.Button button95;
        private System.Windows.Forms.Button button96;
        private System.Windows.Forms.Button button97;
        private System.Windows.Forms.Button button98;
        private System.Windows.Forms.Button button99;
        private System.Windows.Forms.Button button100;
        private System.Windows.Forms.Button button101;
        private System.Windows.Forms.Button button102;
        private System.Windows.Forms.Button button103;
        private System.Windows.Forms.Button button104;
        private System.Windows.Forms.Button button105;
        private System.Windows.Forms.Button button106;
        private System.Windows.Forms.Button button107;
        private System.Windows.Forms.Button button108;
        private System.Windows.Forms.Button button109;
        private System.Windows.Forms.Button button110;
        private System.Windows.Forms.Button button111;
        private System.Windows.Forms.Button button112;
        private System.Windows.Forms.Button button113;
        private System.Windows.Forms.Button button114;
        private System.Windows.Forms.Button button115;
        private System.Windows.Forms.Button button116;
        private System.Windows.Forms.Button button117;
        private System.Windows.Forms.Button button118;
        private System.Windows.Forms.Button button119;
        private System.Windows.Forms.Button button120;
        private System.Windows.Forms.Button button121;
        private System.Windows.Forms.Button button122;
        private System.Windows.Forms.Button button123;
        private System.Windows.Forms.Button button124;
        private System.Windows.Forms.Button button125;
        private System.Windows.Forms.Button button126;
        private System.Windows.Forms.Button button127;
        private System.Windows.Forms.Button button128;
        private System.Windows.Forms.Button button129;
        private System.Windows.Forms.Button button130;
        private System.Windows.Forms.Button button131;
        private System.Windows.Forms.Button button132;
        private System.Windows.Forms.Button button133;
        private System.Windows.Forms.Button button134;
        private System.Windows.Forms.Button button135;
        private System.Windows.Forms.Button button136;
        private System.Windows.Forms.Button button137;
        private System.Windows.Forms.Button button138;
        private System.Windows.Forms.Button button139;
        private System.Windows.Forms.Button button140;
        private System.Windows.Forms.Button button141;
        private System.Windows.Forms.Button button142;
        private System.Windows.Forms.Button button143;
        private System.Windows.Forms.Button button144;
        private System.Windows.Forms.Button button145;
        private System.Windows.Forms.Button button146;
        private System.Windows.Forms.Button button147;
        private System.Windows.Forms.Button button148;
        private System.Windows.Forms.Button button149;
        private System.Windows.Forms.Button button150;
        private System.Windows.Forms.Button button151;
        private System.Windows.Forms.Button button152;
        private System.Windows.Forms.Button button153;
        private System.Windows.Forms.Button button154;
        private System.Windows.Forms.Button button155;
        private System.Windows.Forms.Button button156;
        private System.Windows.Forms.Button button157;
        private System.Windows.Forms.Button button158;
        private System.Windows.Forms.Button button159;
        private System.Windows.Forms.Button button160;
        private System.Windows.Forms.Button button161;
        private System.Windows.Forms.Button button162;
        private System.Windows.Forms.Button button163;
        private System.Windows.Forms.Button button164;
        private System.Windows.Forms.Button button165;
        private System.Windows.Forms.Button button166;
        private System.Windows.Forms.Button button167;
        private System.Windows.Forms.Button button168;
        private System.Windows.Forms.Button button169;
        private System.Windows.Forms.Button button170;
        private System.Windows.Forms.Button button171;
        private System.Windows.Forms.Button button172;
        private System.Windows.Forms.Button button173;
        private System.Windows.Forms.Button button174;
        private System.Windows.Forms.Button button175;
        private System.Windows.Forms.Button button176;
        private System.Windows.Forms.Button button177;
        private System.Windows.Forms.Button button178;
        private System.Windows.Forms.Button button179;
        private System.Windows.Forms.Button button180;
        private System.Windows.Forms.Button button181;
        private System.Windows.Forms.Button button182;
        private System.Windows.Forms.Button button183;
        private System.Windows.Forms.Button button184;
        private System.Windows.Forms.Button button185;
        private System.Windows.Forms.Button button186;
        private System.Windows.Forms.Button button187;
        private System.Windows.Forms.Button button188;
        private System.Windows.Forms.Button button189;
        private System.Windows.Forms.Button button190;
        private System.Windows.Forms.Button button191;
        private System.Windows.Forms.Button button192;
        private System.Windows.Forms.Button button193;
        private System.Windows.Forms.Button button194;
        private System.Windows.Forms.Button button195;
        private System.Windows.Forms.Button button196;
        private System.Windows.Forms.Button button197;
        private System.Windows.Forms.Button button198;
        private System.Windows.Forms.Button button199;
        private System.Windows.Forms.Button button200;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button ReadRulls;
        private System.Windows.Forms.Button button201;
    }
}

