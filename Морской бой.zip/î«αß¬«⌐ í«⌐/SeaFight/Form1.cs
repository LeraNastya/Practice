﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace SeaFight
{
    public partial class Form1 : Form
    {
        int shag = 1;
        int flagAttac = -1;
        int CountPole = 81;
        static int CountShip = 6;
        int CompWin = CountShip;
        int PlayerWin = CountShip;
        int CountMyShip = 0;
        List<Button> ListComp = new List<Button>();
        List<Button> ListPlayer = new List<Button>();
        
        public Form1()
        {
            InitializeComponent();
            richTextBox1.SelectionAlignment = HorizontalAlignment.Center;
            richTextBox1.Text = "Расположите одиночные корабли";
        }
        public void CompRaspolojenye()
        {
            richTextBox1.Text = "";
            Random rnd = new Random();
            int h = 0;
            for (int i = 0; i < 100000; i++)
            {
                if (h == 0 || h == 1 || h == 2)
                {
                    int a = rnd.Next(129, 191);
                    if (ListComp.Contains((Button)this.Controls.Find("button" + (a + 9), true)[0]) == false)
                        if (ListComp.Contains((Button)this.Controls.Find("button" + (a - 9), true)[0]) == false)
                            if (ListComp.Contains((Button)this.Controls.Find("button" + (a + 1), true)[0]) == false)
                                if (ListComp.Contains((Button)this.Controls.Find("button" + (a - 1), true)[0]) == false)
                                    if (ListComp.Contains((Button)this.Controls.Find("button" + a, true)[0]) == false && a != 137 && a != 146 && a != 155 && a != 164 && a != 173 && a != 182)
                                    {
                                        ListComp.Add((Button)this.Controls.Find("button" + a, true)[0]);
                                        h++;
                                    }
                }
                else if (h==3 || h == 4)
                {
                    int a = rnd.Next(129, 191);
                    if(a != 137 && a != 146 && a != 155 && a != 164 && a != 173 && a != 182)
                      if (ListComp.Contains((Button)this.Controls.Find("button" + a, true)[0]) == false)
                        if (ListComp.Contains((Button)this.Controls.Find("button" + (a + 1), true)[0]) == false)
                            if (ListComp.Contains((Button)this.Controls.Find("button" + (a + 2), true)[0]) == false)
                                if (ListComp.Contains((Button)this.Controls.Find("button" + (a - 1), true)[0]) == false)
                                    if (ListComp.Contains((Button)this.Controls.Find("button" + (a - 9), true)[0]) == false)
                                        if (ListComp.Contains((Button)this.Controls.Find("button" + (a - 8), true)[0]) == false)
                                            if (ListComp.Contains((Button)this.Controls.Find("button" + (a + 9), true)[0]) == false)
                                                if (ListComp.Contains((Button)this.Controls.Find("button" + (a + 10), true)[0]) == false)
                                                {
                                                    ListComp.Add((Button)this.Controls.Find("button" + a, true)[0]);
                                                    ListComp.Add((Button)this.Controls.Find("button" + (a + 1), true)[0]);
                                                    h++;
                                                }
                }
                else if (h == 5)
                {
                    int a = rnd.Next(137, 182);
                    if (a != 137 && a != 146 && a != 155 && a != 164 && a != 173 && a != 182)
                      if (ListComp.Contains((Button)this.Controls.Find("button" + a, true)[0]) == false)
                        if (ListComp.Contains((Button)this.Controls.Find("button" + (a + 9), true)[0]) == false)
                            if (ListComp.Contains((Button)this.Controls.Find("button" + (a - 9), true)[0]) == false)
                                if (ListComp.Contains((Button)this.Controls.Find("button" + (a - 18), true)[0]) == false)
                                    if (ListComp.Contains((Button)this.Controls.Find("button" + (a + 18), true)[0]) == false)
                                        if (ListComp.Contains((Button)this.Controls.Find("button" + (a - 8), true)[0]) == false)
                                            if (ListComp.Contains((Button)this.Controls.Find("button" + (a - 10), true)[0]) == false)
                                                if (ListComp.Contains((Button)this.Controls.Find("button" + (a + 8), true)[0]) == false)
                                                    if (ListComp.Contains((Button)this.Controls.Find("button" + (a + 10), true)[0]) == false)
                                                        if (ListComp.Contains((Button)this.Controls.Find("button" + (a + 1), true)[0]) == false)
                                                            if (ListComp.Contains((Button)this.Controls.Find("button" + (a - 1), true)[0]) == false)
                                                            {
                                                                ListComp.Add((Button)this.Controls.Find("button" + a, true)[0]);
                                                                ListComp.Add((Button)this.Controls.Find("button" + (a + 9), true)[0]);
                                                                ListComp.Add((Button)this.Controls.Find("button" + (a - 9), true)[0]);
                                                                h++;
                                                            }
                }
                if (h == CountShip)
                    break;
            }
        }

       

        private void button100_Click(object sender, EventArgs e)
        {
            if (richTextBox1.Text == "Расположите одиночные корабли")
            {
                if (CountMyShip == 0 || CountMyShip == 1 || CountMyShip == 2)
                {
                    for (int i = 1; i <= 100; i++)
                    {
                        if ((Button)sender == this.Controls.Find("button" + i, true)[0])
                        {
                            ((Button)sender).BackColor = Color.LightPink;
                            ((Button)sender).Enabled = false;
                            ListPlayer.Add((Button)sender);

                            this.Controls.Find("button" + (i + 9), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i - 9), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i + 1), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i + 2), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i - 1), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i - 2), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i + 18), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i - 18), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i + 10), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i - 10), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i + 8), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i - 8), true)[0].Enabled = false;
                        }
                    }
                    CountMyShip++;
                    if (CountMyShip == 3) richTextBox1.Text = "Расположите двойные корабли";
                }
                
            }
            else if (richTextBox1.Text == "Расположите двойные корабли")
            {
                if (CountMyShip == 3 || CountMyShip == 4)
                {
                    for (int i = 1; i <= 100; i++)
                    {
                        if ((Button)sender == this.Controls.Find("button" + i, true)[0])
                        {
                            ((Button)sender).BackColor = Color.LightPink;
                            this.Controls.Find("button" + (i + 1), true)[0].BackColor = Color.LightPink;
                           
                            ListPlayer.Add((Button)sender);
                            ListPlayer.Add((Button)this.Controls.Find("button" + (i + 1), true)[0]);

                            ((Button)sender).Enabled = false;
                            this.Controls.Find("button" + (i + 1), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i + 2), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i + 3), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i - 1), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i - 2), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i + 9), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i - 9), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i + 10), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i - 10), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i + 11), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i + 8), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i - 8), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i - 7), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i + 18), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i - 18), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i + 19), true)[0].Enabled = false;
                            this.Controls.Find("button" + (i - 17), true)[0].Enabled = false;

                        }
                    }
                    CountMyShip++;
                    if (CountMyShip==5) richTextBox1.Text = "Расположите тройной корабль";
                } 
            }
            else if (richTextBox1.Text == "Расположите тройной корабль")
            {
                if (CountMyShip == 5)
                {
                    for (int i = 1; i <= 100; i++)
                    {
                        if ((Button)sender == this.Controls.Find("button" + i, true)[0])
                        {
                            ((Button)sender).BackColor = Color.LightPink;
                            this.Controls.Find("button" + (i + 9), true)[0].BackColor = Color.LightPink;
                            this.Controls.Find("button" + (i - 9), true)[0].BackColor = Color.LightPink;

                            ListPlayer.Add((Button)sender);
                            ListPlayer.Add((Button)this.Controls.Find("button" + (i + 9), true)[0]);
                            ListPlayer.Add((Button)this.Controls.Find("button" + (i - 9), true)[0]);

                            ((Button)sender).Enabled = false;
                        }
                    }
                    CountMyShip++;
                }
            }

            if (CountMyShip >= CountShip && (richTextBox1.Text == "Расположите тройной корабль" || richTextBox1.Text == "Расположите двойные корабли" || richTextBox1.Text == "Расположите одиночные корабли"))
            {
                CompRaspolojenye();
                for (int i = 20; i <= 100; i++)
                {
                    this.Controls.Find("button" + i, true)[0].Enabled = false;
                }
                for (int i = 120; i <= 200; i++)
                {
                    this.Controls.Find("button" + i, true)[0].Enabled = true;
                }
                richTextBox1.Text = "Ход игрока. Атакуйте!";
                return;
            } //Завершение расположеня. Дальше код для самой игры
        }

        async void AttacComp()
        { 
            //Атака при ранении
            if (flagAttac>=1)
            {
                shag = 1;
                int i = flagAttac;
                if (shag == 1)
                {
                    if (this.Controls.Find("button" + (i + 1), true)[0].BackColor == Color.LightPink)
                    {
                        this.Controls.Find("button" + (i + 1), true)[0].BackColor = Color.Red;
                        this.Controls.Find("button" + i, true)[0].BackColor = Color.Red;
                        richTextBox1.Text = "Убит! Противник атакует еще раз!"; //?????????????????????
                        await Task.Delay(700);
                        Thread.Sleep(700);
                        CompWin--;
                    }
                    else if (this.Controls.Find("button" + (i + 1), true)[0].BackColor == Color.White)
                    {
                        this.Controls.Find("button" + (i + 1), true)[0].BackColor = Color.DarkGray;
                        richTextBox1.Text = "Ход игрока. Атакуйте!";
                        Thread.Sleep(300);
                        //Разблокировка кнопок
                        for (int a = 120; a <= 200; a++)
                        {
                            if (this.Controls.Find("button" + a, true)[0].BackColor != Color.DarkGray)
                                if (this.Controls.Find("button" + a, true)[0].BackColor != Color.Orange)
                                    if (this.Controls.Find("button" + a, true)[0].BackColor != Color.Red)
                                        this.Controls.Find("button" + a, true)[0].Enabled = true;
                        }
                        //Разблокировка кнопок
                    }
                    else if (this.Controls.Find("button" + (i + 1), true)[0].BackColor == Color.Orange || this.Controls.Find("button" + (i + 1), true)[0].BackColor == Color.DarkGray)
                    {
                        shag = -1;
                    }
                }
                if (shag == -1)
                {
                    if (this.Controls.Find("button" + (i - 1), true)[0].BackColor == Color.LightPink)
                    {
                        this.Controls.Find("button" + (i - 1), true)[0].BackColor = Color.Red;
                        this.Controls.Find("button" + i, true)[0].BackColor = Color.Red;
                        richTextBox1.Text = "Убит! Противник атакует еще раз!";
                        await Task.Delay(700);
                        Thread.Sleep(700);
                        CompWin--;
                    }
                    else if (this.Controls.Find("button" + (i - 1), true)[0].BackColor == Color.White)
                    {
                        this.Controls.Find("button" + (i - 1), true)[0].BackColor = Color.DarkGray;
                        richTextBox1.Text = "Ход игрока. Атакуйте!";
                        Thread.Sleep(300);
                        //Разблокировка кнопок
                        for (int a = 120; a <= 200; a++)
                        {
                            if (this.Controls.Find("button" + a, true)[0].BackColor != Color.DarkGray)
                                if (this.Controls.Find("button" + a, true)[0].BackColor != Color.Orange)
                                    if (this.Controls.Find("button" + a, true)[0].BackColor != Color.Red)
                                        this.Controls.Find("button" + a, true)[0].Enabled = true;
                        }
                        //Разблокировка кнопок
                    }
                    else if (this.Controls.Find("button" + (i - 1), true)[0].BackColor == Color.Orange || this.Controls.Find("button" + (i - 1), true)[0].BackColor == Color.DarkGray)
                    {
                        shag = +9;
                    }
                }
                //тройной корабль
                if (shag == +9)
                {
                    if (this.Controls.Find("button" + (i + 9), true)[0].BackColor == Color.LightPink)
                    {
                        if (this.Controls.Find("button" + (i - 9), true)[0].BackColor == Color.Orange)
                        {
                            this.Controls.Find("button" + i, true)[0].BackColor = Color.Red;
                            this.Controls.Find("button" + (i - 9), true)[0].BackColor = Color.Red;
                            this.Controls.Find("button" + (i + 9), true)[0].BackColor = Color.Red;
                            richTextBox1.Text = "Убит! Противник атакует еще раз!";
                            await Task.Delay(700);
                            Thread.Sleep(700);
                            CompWin--;
                        }
                        else
                        {
                            if (this.Controls.Find("button" + (i + 18), true)[0].BackColor == Color.Orange)
                            {
                                this.Controls.Find("button" + i, true)[0].BackColor = Color.Red;
                                this.Controls.Find("button" + (i + 9), true)[0].BackColor = Color.Red;
                                this.Controls.Find("button" + (i + 18), true)[0].BackColor = Color.Red;
                                richTextBox1.Text = "Убит! Противник атакует еще раз!";
                                await Task.Delay(700);
                                Thread.Sleep(700);
                                CompWin--;
                            }
                            else if (this.Controls.Find("button" + (i + 18), true)[0].BackColor == Color.LightPink)
                            {
                                this.Controls.Find("button" + (i + 9), true)[0].BackColor = Color.Orange;
                                richTextBox1.Text = "Ранен! Противник атакует еще раз!";
                                await Task.Delay(700);
                                Thread.Sleep(700);
                                this.Controls.Find("button" + i, true)[0].BackColor = Color.Red;
                                this.Controls.Find("button" + (i + 9), true)[0].BackColor = Color.Red;
                                this.Controls.Find("button" + (i + 18), true)[0].BackColor = Color.Red;
                                richTextBox1.Text = "Убит! Противник атакует еще раз!";
                                await Task.Delay(700);
                                Thread.Sleep(700);
                                CompWin--;
                            }
                            else if (this.Controls.Find("button" + (i + 18), true)[0].BackColor == Color.White)
                            {
                                this.Controls.Find("button" + (i + 9), true)[0].BackColor = Color.Orange;
                                this.Controls.Find("button" + i, true)[0].Enabled = false;
                                richTextBox1.Text = "Ранен! Противник атакует еще раз!";
                                await Task.Delay(700);
                                Thread.Sleep(700);
                                this.Controls.Find("button" + (i + 18), true)[0].BackColor = Color.DarkGray;
                                richTextBox1.Text = "Ход игрока. Атакуйте!";
                                Thread.Sleep(300);
                                //Разблокировка кнопок
                                for (int a = 120; a <= 200; a++)
                                {
                                    if (this.Controls.Find("button" + a, true)[0].BackColor != Color.DarkGray)
                                        if (this.Controls.Find("button" + a, true)[0].BackColor != Color.Orange)
                                            if (this.Controls.Find("button" + a, true)[0].BackColor != Color.Red)
                                                this.Controls.Find("button" + a, true)[0].Enabled = true;
                                }
                                //Разблокировка кнопок
                            }
                            else if (this.Controls.Find("button" + (i + 18), true)[0].BackColor == Color.DarkGray)
                            {
                                this.Controls.Find("button" + (i + 9), true)[0].BackColor = Color.Orange;
                                richTextBox1.Text = "Ранен! Противник атакует еще раз!";
                                await Task.Delay(700);
                                Thread.Sleep(700);
                                this.Controls.Find("button" + i, true)[0].BackColor = Color.Red;
                                this.Controls.Find("button" + (i + 9), true)[0].BackColor = Color.Red;
                                this.Controls.Find("button" + (i - 9), true)[0].BackColor = Color.Red;
                                richTextBox1.Text = "Убит! Противник атакует еще раз!";
                                await Task.Delay(700);
                                Thread.Sleep(700);
                                CompWin--;
                            }
                        }
                    }
                    else if (this.Controls.Find("button" + (i + 9), true)[0].BackColor == Color.White)
                    {
                        this.Controls.Find("button" + (i + 9), true)[0].BackColor = Color.DarkGray;
                        richTextBox1.Text = "Ход игрока. Атакуйте!";
                        Thread.Sleep(300);
                        //Разблокировка кнопок
                        for (int a = 120; a <= 200; a++)
                        {
                            if (this.Controls.Find("button" + a, true)[0].BackColor != Color.DarkGray)
                                if (this.Controls.Find("button" + a, true)[0].BackColor != Color.Orange)
                                    if (this.Controls.Find("button" + a, true)[0].BackColor != Color.Red)
                                        this.Controls.Find("button" + a, true)[0].Enabled = true;
                        }
                        //Разблокировка кнопок
                    }
                    else if (this.Controls.Find("button" + (i + 9), true)[0].BackColor == Color.Orange || this.Controls.Find("button" + (i + 9), true)[0].BackColor == Color.DarkGray)
                    {
                        shag = -9;
                    }
                }

                if (shag == -9)
                {
                    if (this.Controls.Find("button" + (i - 9), true)[0].BackColor == Color.LightPink)
                    {
                        if (this.Controls.Find("button" + (i + 9), true)[0].BackColor == Color.Orange)
                        {
                            this.Controls.Find("button" + i, true)[0].BackColor = Color.Red;
                            this.Controls.Find("button" + (i - 9), true)[0].BackColor = Color.Red;
                            this.Controls.Find("button" + (i + 9), true)[0].BackColor = Color.Red;
                            richTextBox1.Text = "Убит! Противник атакует еще раз!";
                            await Task.Delay(700);
                            Thread.Sleep(700);
                            CompWin--;
                        }
                        else
                        {
                            if (this.Controls.Find("button" + (i - 18), true)[0].BackColor == Color.Orange)
                            {
                                this.Controls.Find("button" + i, true)[0].BackColor = Color.Red;
                                this.Controls.Find("button" + (i - 9), true)[0].BackColor = Color.Red;
                                this.Controls.Find("button" + (i - 18), true)[0].BackColor = Color.Red;
                                richTextBox1.Text = "Убит! Противник атакует еще раз!";
                                await Task.Delay(700);
                                Thread.Sleep(700);
                                CompWin--;
                            }
                            else if (this.Controls.Find("button" + (i - 18), true)[0].BackColor == Color.LightPink)
                            {
                                this.Controls.Find("button" + (i - 9), true)[0].BackColor = Color.Orange;
                                this.Controls.Find("button" + i, true)[0].Enabled = false;
                                richTextBox1.Text = "Ранен! Противник атакует еще раз!";
                                await Task.Delay(700);
                                Thread.Sleep(700);
                                this.Controls.Find("button" + i, true)[0].BackColor = Color.Red;
                                this.Controls.Find("button" + (i - 9), true)[0].BackColor = Color.Red;
                                this.Controls.Find("button" + (i - 18), true)[0].BackColor = Color.Red;
                                richTextBox1.Text = "Убит! Противник атакует еще раз!";
                                await Task.Delay(700);
                                Thread.Sleep(700);
                                CompWin--;
                            }
                            else if (this.Controls.Find("button" + (i - 18), true)[0].BackColor == Color.White)
                            {
                                this.Controls.Find("button" + (i - 9), true)[0].BackColor = Color.Orange;
                                this.Controls.Find("button" + i, true)[0].Enabled = false;
                                richTextBox1.Text = "Ранен! Противник атакует еще раз!";
                                await Task.Delay(700);
                                Thread.Sleep(700);
                                this.Controls.Find("button" + (i - 18), true)[0].BackColor = Color.DarkGray;
                                richTextBox1.Text = "Ход игрока. Атакуйте!";
                                Thread.Sleep(300);
                                //Разблокировка кнопок
                                for (int a = 120; a <= 200; a++)
                                {
                                    if (this.Controls.Find("button" + a, true)[0].BackColor != Color.DarkGray)
                                        if (this.Controls.Find("button" + a, true)[0].BackColor != Color.Orange)
                                            if (this.Controls.Find("button" + a, true)[0].BackColor != Color.Red)
                                                this.Controls.Find("button" + a, true)[0].Enabled = true;
                                }
                                //Разблокировка кнопок
                            }
                            else if (this.Controls.Find("button" + (i - 18), true)[0].BackColor == Color.DarkGray)
                            {
                                this.Controls.Find("button" + (i - 9), true)[0].BackColor = Color.Orange;
                                richTextBox1.Text = "Ранен! Противник атакует еще раз!";
                                await Task.Delay(700);
                                Thread.Sleep(700);

                                this.Controls.Find("button" + i, true)[0].BackColor = Color.Red;
                                this.Controls.Find("button" + (i + 9), true)[0].BackColor = Color.Red;
                                this.Controls.Find("button" + (i - 9), true)[0].BackColor = Color.Red;
                                richTextBox1.Text = "Убит! Противник атакует еще раз!";
                                await Task.Delay(700);
                                Thread.Sleep(700);
                                CompWin--;
                            }
                        }
                    }
                    else if (this.Controls.Find("button" + (i - 9), true)[0].BackColor == Color.White)
                    {
                        this.Controls.Find("button" + (i - 9), true)[0].BackColor = Color.DarkGray;
                        richTextBox1.Text = "Ход игрока. Атакуйте!";
                        Thread.Sleep(300);
                        //Разблокировка кнопок
                        for (int a = 120; a <= 200; a++)
                        {
                            if (this.Controls.Find("button" + a, true)[0].BackColor != Color.DarkGray)
                                if (this.Controls.Find("button" + a, true)[0].BackColor != Color.Orange)
                                    if (this.Controls.Find("button" + a, true)[0].BackColor != Color.Red)
                                        this.Controls.Find("button" + a, true)[0].Enabled = true;
                        }
                        //Разблокировка кнопок
                    }
                    else if (this.Controls.Find("button" + (i - 9), true)[0].BackColor == Color.Orange || this.Controls.Find("button" + (i - 9), true)[0].BackColor == Color.DarkGray)
                    {
                        shag = 1;
                    }

                }
            }
            else //Если флаг отрицательный идет рандомный выбор поля
            {
                Random r = new Random();
                Lab:
                int index = r.Next(20, 101);
                if (this.Controls.Find("button" + index, true)[0].BackColor == Color.DarkGray || this.Controls.Find("button" + index, true)[0].BackColor == Color.Orange || this.Controls.Find("button" + index, true)[0].BackColor == Color.Red)
                    goto Lab;
                if (this.Controls.Find("button" + (index + 1), true)[0].BackColor == Color.Red)
                    goto Lab;
                if (this.Controls.Find("button" + (index - 1), true)[0].BackColor == Color.Red)
                    goto Lab;
                if (this.Controls.Find("button" + (index + 9), true)[0].BackColor == Color.Red)
                    goto Lab;
                if (this.Controls.Find("button" + (index - 9), true)[0].BackColor == Color.Red)
                    goto Lab;

                if (this.Controls.Find("button" + index, true)[0].BackColor == Color.LightPink)
                {
                    for (int i = 20; i <= 100; i++)
                    {
                        if (i == index)
                        {
                            if (ListPlayer.Contains((Button)this.Controls.Find("button" + (i + 1), true)[0]) == true || ListPlayer.Contains((Button)this.Controls.Find("button" + (i - 1), true)[0]) == true)
                            {
                                this.Controls.Find("button" + i, true)[0].BackColor = Color.Orange;
                                this.Controls.Find("button" + i, true)[0].Enabled = false;
                                richTextBox1.Text = "Ранен! Противник атакует еще раз!";
                                if (this.Controls.Find("button" + (i - 1), true)[0].BackColor == Color.Orange)
                                {
                                    this.Controls.Find("button" + (i - 1), true)[0].BackColor = Color.Red;
                                    this.Controls.Find("button" + i, true)[0].BackColor = Color.Red;
                                    richTextBox1.Text = "Убит! Противник атакует еще раз!";
                                    CompWin--;
                                }
                                if (this.Controls.Find("button" + (i + 1), true)[0].BackColor == Color.Orange)
                                {
                                    this.Controls.Find("button" + (i + 1), true)[0].BackColor = Color.Red;
                                    this.Controls.Find("button" + i, true)[0].BackColor = Color.Red;
                                    richTextBox1.Text = "Убит! Противник атакует еще раз!";
                                    CompWin--;
                                }
                                await Task.Delay(700);
                                Thread.Sleep(700);
                            }
                            else if (ListPlayer.Contains((Button)this.Controls.Find("button" + (i + 9), true)[0]) == true || ListPlayer.Contains((Button)this.Controls.Find("button" + (i - 9), true)[0]) == true)
                            {
                                this.Controls.Find("button" + index, true)[0].BackColor = Color.Orange;
                                this.Controls.Find("button" + index, true)[0].Enabled = false;
                                richTextBox1.Text = "Ранен! Противник атакует еще раз!";
                                if (this.Controls.Find("button" + (i + 9), true)[0].BackColor == Color.Orange && this.Controls.Find("button" + (i - 9), true)[0].BackColor == Color.Orange)
                                {
                                    this.Controls.Find("button" + (i + 9), true)[0].BackColor = Color.Red;
                                    this.Controls.Find("button" + (i - 9), true)[0].BackColor = Color.Red;
                                    this.Controls.Find("button" + i, true)[0].BackColor = Color.Red;
                                    richTextBox1.Text = "Убит! Противник атакует еще раз!";
                                    CompWin--;
                                }
                                if (this.Controls.Find("button" + (i + 9), true)[0].BackColor == Color.Orange && this.Controls.Find("button" + (i + 18), true)[0].BackColor == Color.Orange)
                                {
                                    this.Controls.Find("button" + (i + 9), true)[0].BackColor = Color.Red;
                                    this.Controls.Find("button" + (i + 18), true)[0].BackColor = Color.Red;
                                    this.Controls.Find("button" + i, true)[0].BackColor = Color.Red;
                                    richTextBox1.Text = "Убит! Противник атакует еще раз!";
                                    CompWin--;
                                }
                                if (this.Controls.Find("button" + (i - 9), true)[0].BackColor == Color.Orange && this.Controls.Find("button" + (i - 18), true)[0].BackColor == Color.Orange)
                                {
                                    this.Controls.Find("button" + (i - 9), true)[0].BackColor = Color.Red;
                                    this.Controls.Find("button" + (i - 18), true)[0].BackColor = Color.Red;
                                    this.Controls.Find("button" + i, true)[0].BackColor = Color.Red;
                                    richTextBox1.Text = "Убит! Противник атакует еще раз!";
                                    CompWin--;
                                }
                                await Task.Delay(700);
                                Thread.Sleep(700);
                            }
                            else
                            {
                                this.Controls.Find("button" + i, true)[0].BackColor = Color.Red;
                                this.Controls.Find("button" + i, true)[0].Enabled = false;
                                richTextBox1.Text = "Убит! Противник атакует еще раз!";
                                CompWin--;
                                await Task.Delay(700);
                                Thread.Sleep(700);
                            }
                            if (richTextBox1.Text == "Ранен! Противник атакует еще раз!")
                            {
                                flagAttac = i;
                                AttacComp();
                            }
                        }
                    }
                }
                else
                {
                    this.Controls.Find("button" + index, true)[0].BackColor = Color.DarkGray;
                    richTextBox1.Text = "Ход игрока. Атакуйте!";
                    Thread.Sleep(300);
                    //Разблокировка кнопок
                    for (int i = 120; i <= 200; i++)
                    {
                        if (this.Controls.Find("button" + i, true)[0].BackColor != Color.DarkGray)
                            if (this.Controls.Find("button" + i, true)[0].BackColor != Color.Orange)
                                if (this.Controls.Find("button" + i, true)[0].BackColor != Color.Red)
                                    this.Controls.Find("button" + i, true)[0].Enabled = true;
                    }
                    //Разблокировка кнопок
                }
            }

            
            if (CompWin == 0)
            {
                for (int i = 1; i <= 200; i++)
                {
                    this.Controls.Find("button" + i, true)[0].Enabled = false;
                }
                MessageBox.Show("Вы проиграли!");
                this.Controls.Find("ReadRulls", true)[0].Enabled = false;
                return;
            }
            if (richTextBox1.Text == "Убит! Противник атакует еще раз!")
            {
                flagAttac = -1;
                AttacComp();
            }
        }

        async void button200_Click(object sender, EventArgs e)
        {
            if (richTextBox1.Text == "Ход игрока. Атакуйте!" || richTextBox1.Text == "Ранен! Атакуйте еще раз!" || richTextBox1.Text == "Убит! Атакуйте еще раз!")
            {
                if (ListComp.Contains((Button)sender) == true)
                {
                    for (int i = 129; i <= 191; i++)
                    {
                        if (((Button)sender).Name == "button" + i.ToString()) //Условия
                        {
                            if (ListComp.Contains((Button)this.Controls.Find("button" + (i + 1), true)[0]) == true || ListComp.Contains((Button)this.Controls.Find("button" + (i - 1), true)[0]) == true)
                            {
                                ((Button)sender).BackColor = Color.Orange;
                                ((Button)sender).Enabled = false;
                                richTextBox1.Text = "Ранен! Атакуйте еще раз!";
                                if (this.Controls.Find("button" + (i - 1), true)[0].BackColor == Color.Orange)
                                {
                                    this.Controls.Find("button" + (i - 1), true)[0].BackColor = Color.Red;
                                    this.Controls.Find("button" + i, true)[0].BackColor = Color.Red;
                                    richTextBox1.Text = "Убит! Атакуйте еще раз!";
                                    PlayerWin--;
                                }
                                if (this.Controls.Find("button" + (i + 1), true)[0].BackColor == Color.Orange)
                                {
                                    this.Controls.Find("button" + (i + 1), true)[0].BackColor = Color.Red;
                                    this.Controls.Find("button" + i, true)[0].BackColor = Color.Red;
                                    richTextBox1.Text = "Убит! Атакуйте еще раз!";
                                    PlayerWin--;
                                }
                            }
                            else if (ListComp.Contains((Button)this.Controls.Find("button" + (i + 9), true)[0]) == true || ListComp.Contains((Button)this.Controls.Find("button" + (i - 9), true)[0]) == true)
                            {
                                ((Button)sender).BackColor = Color.Orange;
                                ((Button)sender).Enabled = false;
                                richTextBox1.Text = "Ранен! Атакуйте еще раз!";
                                if (this.Controls.Find("button" + (i + 9), true)[0].BackColor == Color.Orange && this.Controls.Find("button" + (i - 9), true)[0].BackColor == Color.Orange)
                                {
                                    this.Controls.Find("button" + (i + 9), true)[0].BackColor = Color.Red;
                                    this.Controls.Find("button" + (i - 9), true)[0].BackColor = Color.Red;
                                    this.Controls.Find("button" + i, true)[0].BackColor = Color.Red;
                                    richTextBox1.Text = "Убит! Атакуйте еще раз!";
                                    PlayerWin--;
                                }
                                if (this.Controls.Find("button" + (i + 9), true)[0].BackColor == Color.Orange && this.Controls.Find("button" + (i + 18), true)[0].BackColor == Color.Orange)
                                {
                                    this.Controls.Find("button" + (i + 9), true)[0].BackColor = Color.Red;
                                    this.Controls.Find("button" + (i + 18), true)[0].BackColor = Color.Red;
                                    this.Controls.Find("button" + i, true)[0].BackColor = Color.Red;
                                    richTextBox1.Text = "Убит! Атакуйте еще раз!";
                                    PlayerWin--;
                                }
                                if (this.Controls.Find("button" + (i - 9), true)[0].BackColor == Color.Orange && this.Controls.Find("button" + (i - 18), true)[0].BackColor == Color.Orange)
                                {
                                    this.Controls.Find("button" + (i - 9), true)[0].BackColor = Color.Red;
                                    this.Controls.Find("button" + (i - 18), true)[0].BackColor = Color.Red;
                                    this.Controls.Find("button" + i, true)[0].BackColor = Color.Red;
                                    richTextBox1.Text = "Убит! Атакуйте еще раз!";
                                    PlayerWin--;
                                }
                            }
                            else
                            {
                                this.Controls.Find("button" + i, true)[0].BackColor = Color.Red;
                                this.Controls.Find("button" + i, true)[0].Enabled = false;    
                                richTextBox1.Text = "Убит! Атакуйте еще раз!";
                                PlayerWin--;
                            }
                        }                   
                    }
                }
                else
                {
                    ((Button)sender).BackColor = Color.DarkGray;
                    ((Button)sender).Enabled = false;
                    richTextBox1.Text = "Мимо! Противник атакует!";
                    //Блокировка кнопок
                    for (int i = 120; i <= 200; i++)
                    {
                        this.Controls.Find("button" + i, true)[0].Enabled = false;
                    }
                    //Блокировка кнопок
                    await Task.Delay(600);
                    Thread.Sleep(600);
                    AttacComp();
                }
            } 
            if (PlayerWin == 0)
            {
                for (int i = 1; i <= 200; i++)
                {
                    this.Controls.Find("button" + i, true)[0].Enabled = false;
                }
                MessageBox.Show("Вы победили!");
                this.Controls.Find("ReadRulls", true)[0].Enabled = false;
            }
            
        }

        private void ReadRulls_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.Count < 2)
            {
                AboutBox1 aboutWindow = new AboutBox1();
                aboutWindow.Show();
            }
        }

        private void button201_Click(object sender, EventArgs e)
        {
            this.Controls.Find("ReadRulls", true)[0].Enabled = true;
            richTextBox1.Text = "Расположите одиночные корабли";
            for (int i = 20; i <= 100; i++)
            {
                this.Controls.Find("button" + i, true)[0].Enabled = true;
                this.Controls.Find("button" + i, true)[0].BackColor = Color.White;
            }
            for (int i = 120; i <= 200; i++)
            {
                this.Controls.Find("button" + i, true)[0].Enabled = true;
                this.Controls.Find("button" + i, true)[0].BackColor = Color.White;
            }
            for (int i = 1; i <= 19; i++)
            {
                this.Controls.Find("button" + i, true)[0].Enabled = false;
                this.Controls.Find("button" + i, true)[0].BackColor = Color.DarkGray;
            }
            this.Controls.Find("button" + 2, true)[0].Text = "А";
            this.Controls.Find("button" + 3, true)[0].Text = "Б";
            this.Controls.Find("button" + 4, true)[0].Text = "В";
            this.Controls.Find("button" + 5, true)[0].Text = "Г";
            this.Controls.Find("button" + 6, true)[0].Text = "Д";
            this.Controls.Find("button" + 7, true)[0].Text = "Е";
            this.Controls.Find("button" + 8, true)[0].Text = "Ж";
            this.Controls.Find("button" + 9, true)[0].Text = "З";
            this.Controls.Find("button" + 10, true)[0].Text = "И";
            for (int i = 11; i <= 19; i++)
            {
                this.Controls.Find("button" + i, true)[0].Text = (i - 10).ToString();
            }

            for (int i = 101; i <= 119; i++)
            {
                this.Controls.Find("button" + i, true)[0].Enabled = false;
                this.Controls.Find("button" + i, true)[0].BackColor = Color.DarkGray;
            }
            this.Controls.Find("button" + 102, true)[0].Text = "А";
            this.Controls.Find("button" + 103, true)[0].Text = "Б";
            this.Controls.Find("button" + 104, true)[0].Text = "В";
            this.Controls.Find("button" + 105, true)[0].Text = "Г";
            this.Controls.Find("button" + 106, true)[0].Text = "Д";
            this.Controls.Find("button" + 107, true)[0].Text = "Е";
            this.Controls.Find("button" + 108, true)[0].Text = "Ж";
            this.Controls.Find("button" + 109, true)[0].Text = "З";
            this.Controls.Find("button" + 110, true)[0].Text = "И";
            for (int i = 111; i <= 119; i++)
            {
                this.Controls.Find("button" + i, true)[0].Text = (i-110).ToString();
            }
            //Внутренние края
            for (int i = 92; i <= 100; i++)
            {
                this.Controls.Find("button" + i, true)[0].Enabled = false;
            }
            for (int i = 192; i <= 200; i++)
            {
                this.Controls.Find("button" + i, true)[0].Enabled = false;
            }
            for (int i = 20; i <= 28; i++)
            {
                this.Controls.Find("button" + i, true)[0].Enabled = false;
            }
            for (int i = 120; i <= 128; i++)
            {
                this.Controls.Find("button" + i, true)[0].Enabled = false;
            }
            for (int i = 20; i <= 92; i=i+9)
            {
                this.Controls.Find("button" + i, true)[0].Enabled = false;
            }
            for (int i = 120; i <= 192; i = i + 9)
            {
                this.Controls.Find("button" + i, true)[0].Enabled = false;
            }
            for (int i = 28; i <= 100; i = i + 9)
            {
                this.Controls.Find("button" + i, true)[0].Enabled = false;
            }
            for (int i = 128; i <= 200; i = i + 9)
            {
                this.Controls.Find("button" + i, true)[0].Enabled = false;
            }
            shag = 1;
            flagAttac = -1;
            CountPole = 81;
            CountShip = 6; //6 для б, 5 для ср, 3 для м
            CompWin = CountShip;
            PlayerWin = CountShip;
            CountMyShip = 0;
            ListComp.Clear();
            ListPlayer.Clear();
        }
    }
}
